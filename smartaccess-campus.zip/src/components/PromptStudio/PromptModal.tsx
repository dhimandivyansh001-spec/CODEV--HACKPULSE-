import React, { useState } from 'react';
import {
  X,
  Copy,
  Check,
  Download,
  Sparkles,
  Palette,
  Layers,
  Code2,
  FileText,
  Sliders,
  ExternalLink,
  BookOpen,
} from 'lucide-react';
import {
  FIGMA_AI_MASTER_PROMPT,
  FIGMA_TOKENS_STUDIO_JSON,
  COMPONENT_VARIANTS_SPEC,
} from '../../data/figmaPrompts';
import { DesignTokenCustomizer } from '../../types/tokens';

interface PromptModalProps {
  isOpen: boolean;
  onClose: () => void;
  tokenConfig: DesignTokenCustomizer;
  onUpdateTokenConfig: (newConfig: Partial<DesignTokenCustomizer>) => void;
}

export const PromptModal: React.FC<PromptModalProps> = ({
  isOpen,
  onClose,
  tokenConfig,
  onUpdateTokenConfig,
}) => {
  const [activeTab, setActiveTab] = useState<'prompt' | 'tokens' | 'components' | 'guide'>('prompt');
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  // Dynamic prompt calculation based on customizer
  const dynamicPrompt = FIGMA_AI_MASTER_PROMPT.replace(
    '#2563EB',
    tokenConfig.primaryColor
  ).replace(
    '10px (Card)',
    `${tokenConfig.radiusPx}px (Card)`
  );

  const dynamicTokensJson = JSON.parse(JSON.stringify(FIGMA_TOKENS_STUDIO_JSON));
  dynamicTokensJson.color.brand.primary['600'].value = tokenConfig.primaryColor;
  dynamicTokensJson.borderRadius.md.value = `${tokenConfig.radiusPx}px`;

  const tokensString = JSON.stringify(dynamicTokensJson, null, 2);

  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownloadJson = () => {
    const blob = new Blob([tokensString], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'smartaccess-figma-tokens.json';
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-6">
      <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-4xl max-h-[92vh] flex flex-col overflow-hidden animate-in fade-in zoom-in-95 duration-150">
        {/* Modal Header */}
        <div className="px-6 py-4 border-b border-slate-200 flex items-center justify-between bg-slate-50/70">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-blue-600 flex items-center justify-center text-white">
              <Sparkles className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-900">
                Figma Prompt & Design Tokens Generator
              </h2>
              <p className="text-xs text-slate-500">
                Copy prompt for Figma AI, import W3C Tokens, and build editable components
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-200/60 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Customization Bar */}
        <div className="px-6 py-3 bg-white border-b border-slate-100 flex flex-wrap items-center justify-between gap-4 text-xs">
          <div className="flex items-center gap-4 flex-wrap">
            <div className="flex items-center gap-2">
              <Sliders className="w-3.5 h-3.5 text-slate-400" />
              <span className="font-semibold text-slate-700">Customize Tokens:</span>
            </div>

            {/* Brand Color Selector */}
            <div className="flex items-center gap-1.5">
              <span className="text-slate-500">Primary:</span>
              {[
                { hex: '#2563EB', name: 'Campus Blue' },
                { hex: '#4F46E5', name: 'Indigo' },
                { hex: '#059669', name: 'Emerald' },
                { hex: '#7C3AED', name: 'Violet' },
                { hex: '#0F172A', name: 'Obsidian' },
              ].map((c) => (
                <button
                  key={c.hex}
                  onClick={() =>
                    onUpdateTokenConfig({ primaryColor: c.hex, primaryName: c.name })
                  }
                  title={c.name}
                  className={`w-5 h-5 rounded-full border transition-all ${
                    tokenConfig.primaryColor === c.hex
                      ? 'ring-2 ring-offset-1 ring-blue-500 scale-110'
                      : 'border-slate-300 opacity-80 hover:opacity-100'
                  }`}
                  style={{ backgroundColor: c.hex }}
                />
              ))}
            </div>

            {/* Corner Radius Selector */}
            <div className="flex items-center gap-1.5 pl-2 border-l border-slate-200">
              <span className="text-slate-500">Radius:</span>
              {[
                { px: 4, label: '4px' },
                { px: 8, label: '8px' },
                { px: 12, label: '12px' },
                { px: 16, label: '16px' },
              ].map((r) => (
                <button
                  key={r.px}
                  onClick={() => onUpdateTokenConfig({ radiusPx: r.px })}
                  className={`px-2 py-0.5 rounded text-[11px] font-medium transition-colors ${
                    tokenConfig.radiusPx === r.px
                      ? 'bg-blue-100 text-blue-700 font-semibold'
                      : 'text-slate-600 hover:bg-slate-100'
                  }`}
                >
                  {r.label}
                </button>
              ))}
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                if (activeTab === 'prompt') handleCopy(dynamicPrompt);
                else if (activeTab === 'tokens') handleCopy(tokensString);
                else if (activeTab === 'components')
                  handleCopy(JSON.stringify(COMPONENT_VARIANTS_SPEC, null, 2));
              }}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-semibold text-xs transition-all shadow-xs cursor-pointer"
            >
              {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? 'Copied to Clipboard!' : 'Copy Current View'}</span>
            </button>
            {activeTab === 'tokens' && (
              <button
                onClick={handleDownloadJson}
                className="flex items-center gap-1.5 px-2.5 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg font-medium text-xs transition-colors"
                title="Download JSON for Figma Tokens Studio"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Export JSON</span>
              </button>
            )}
          </div>
        </div>

        {/* Tab Selection */}
        <div className="flex items-center gap-2 px-6 pt-3 border-b border-slate-200 bg-slate-50/50">
          <button
            onClick={() => setActiveTab('prompt')}
            className={`pb-2.5 text-xs font-semibold flex items-center gap-1.5 border-b-2 transition-colors cursor-pointer ${
              activeTab === 'prompt'
                ? 'border-blue-600 text-blue-600'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>Figma AI Master Prompt</span>
          </button>
          <button
            onClick={() => setActiveTab('tokens')}
            className={`pb-2.5 text-xs font-semibold flex items-center gap-1.5 border-b-2 transition-colors cursor-pointer ${
              activeTab === 'tokens'
                ? 'border-blue-600 text-blue-600'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <Palette className="w-3.5 h-3.5" />
            <span>Design Tokens JSON (W3C / Tokens Studio)</span>
          </button>
          <button
            onClick={() => setActiveTab('components')}
            className={`pb-2.5 text-xs font-semibold flex items-center gap-1.5 border-b-2 transition-colors cursor-pointer ${
              activeTab === 'components'
                ? 'border-blue-600 text-blue-600'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <Layers className="w-3.5 h-3.5" />
            <span>Component Sets & Variants</span>
          </button>
          <button
            onClick={() => setActiveTab('guide')}
            className={`pb-2.5 text-xs font-semibold flex items-center gap-1.5 border-b-2 transition-colors cursor-pointer ${
              activeTab === 'guide'
                ? 'border-blue-600 text-blue-600'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <BookOpen className="w-3.5 h-3.5" />
            <span>Figma Implementation Guide</span>
          </button>
        </div>

        {/* Tab Content Body */}
        <div className="flex-1 overflow-y-auto p-6 bg-slate-900 text-slate-100 font-mono text-xs leading-relaxed selection:bg-blue-500 selection:text-white">
          {activeTab === 'prompt' && (
            <div className="relative">
              <pre className="whitespace-pre-wrap font-sans text-xs sm:text-sm text-slate-200">
                {dynamicPrompt}
              </pre>
            </div>
          )}

          {activeTab === 'tokens' && (
            <div>
              <div className="mb-3 font-sans text-xs text-slate-400 bg-slate-800/80 p-3 rounded-lg border border-slate-700">
                💡 <strong>Usage Tip:</strong> Compatible with Figma's <em>Tokens Studio for Figma</em> plugin or can be parsed via Figma Plugin API into Local Variables (Collections: Color, Dimensions, Typography).
              </div>
              <pre className="whitespace-pre text-emerald-400 font-mono text-xs">{tokensString}</pre>
            </div>
          )}

          {activeTab === 'components' && (
            <div className="space-y-4 font-sans">
              <div className="text-xs text-slate-400 mb-2">
                Figma Component Sets specifications with Variant Properties, Booleans, and Auto-Layout rules:
              </div>
              {COMPONENT_VARIANTS_SPEC.map((cmp, i) => (
                <div
                  key={i}
                  className="bg-slate-800/80 rounded-xl p-4 border border-slate-700/80"
                >
                  <div className="flex items-center justify-between mb-2">
                    <span className="font-bold text-white text-sm">❖ {cmp.name}</span>
                    <span className="text-[11px] px-2 py-0.5 rounded bg-blue-900/60 text-blue-300">
                      Component Set
                    </span>
                  </div>
                  <p className="text-xs text-slate-300 mb-3">{cmp.description}</p>
                  <div className="space-y-1.5 text-xs">
                    <div className="text-slate-400 font-semibold">Variant Properties:</div>
                    {cmp.variants.map((v, idx) => (
                      <div key={idx} className="flex items-center gap-2 pl-2">
                        <span className="text-amber-300 font-mono">{v.property}:</span>
                        <span className="text-slate-300">
                          {v.values.join(' | ')}
                        </span>
                      </div>
                    ))}
                    <div className="mt-2 text-slate-400">
                      Tokens Bound: <span className="text-sky-300 font-mono">{cmp.tokensUsed.join(', ')}</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}

          {activeTab === 'guide' && (
            <div className="font-sans space-y-4 text-xs sm:text-sm text-slate-200">
              <div className="bg-blue-950/60 border border-blue-800/80 rounded-xl p-4">
                <h4 className="font-bold text-blue-300 text-sm mb-1">
                  How to generate this in Figma (3 Workflows)
                </h4>
                <p className="text-xs text-slate-300">
                  Follow these step-by-step methods depending on which Figma feature or plugin you use:
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                <div className="bg-slate-800/80 p-4 rounded-xl border border-slate-700">
                  <span className="text-blue-400 font-bold block mb-1 text-xs">METHOD 1</span>
                  <h5 className="font-semibold text-white mb-2">Figma AI ("Make Designs")</h5>
                  <ol className="list-decimal list-inside space-y-1 text-xs text-slate-300">
                    <li>Open Figma and press <strong>Cmd + K</strong> or click the Figma AI icon in toolbar.</li>
                    <li>Select <strong>Make Designs</strong>.</li>
                    <li>Copy and paste the <strong>Figma AI Master Prompt</strong> into the prompt bar.</li>
                    <li>Figma generates responsive Auto-Layout frames with color variables and editable text.</li>
                  </ol>
                </div>

                <div className="bg-slate-800/80 p-4 rounded-xl border border-slate-700">
                  <span className="text-blue-400 font-bold block mb-1 text-xs">METHOD 2</span>
                  <h5 className="font-semibold text-white mb-2">Tokens Studio (Figma Plugin)</h5>
                  <ol className="list-decimal list-inside space-y-1 text-xs text-slate-300">
                    <li>Install the <strong>Tokens Studio for Figma</strong> community plugin.</li>
                    <li>Switch to the <strong>Design Tokens JSON</strong> tab above and click <em>Export JSON</em>.</li>
                    <li>In the plugin, click <strong>Tools → Load from JSON</strong>.</li>
                    <li>Click <strong>Apply to document</strong>: All colors, radii, and spacing variables bind automatically!</li>
                  </ol>
                </div>

                <div className="bg-slate-800/80 p-4 rounded-xl border border-slate-700">
                  <span className="text-blue-400 font-bold block mb-1 text-xs">METHOD 3</span>
                  <h5 className="font-semibold text-white mb-2">Claude / Cursor to Figma</h5>
                  <ol className="list-decimal list-inside space-y-1 text-xs text-slate-300">
                    <li>Use the <strong>html.to.design</strong> or <strong>Builder.io</strong> Figma plugin.</li>
                    <li>Import this live web app URL directly into Figma to get 100% editable vector layers, frames, and components!</li>
                  </ol>
                </div>
              </div>

              <div className="bg-slate-800/60 p-4 rounded-xl border border-slate-700 text-xs">
                <span className="font-semibold text-white">Component Architecture Tip:</span>
                <p className="text-slate-300 mt-1">
                  Keep each campus facility marker (Ramp, Lift, Toilet, Entrance) as an instance of a single master <code>Map/Marker-Pin</code> component with a <code>Type</code> variant. This lets you change iconography across all 50+ map locations in a single click.
                </p>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-6 py-3 border-t border-slate-200 bg-slate-50 flex items-center justify-between text-xs text-slate-600">
          <span>
            Current Primary: <strong className="font-mono">{tokenConfig.primaryColor}</strong> ({tokenConfig.primaryName}) · Corner Radius: <strong>{tokenConfig.radiusPx}px</strong>
          </span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 bg-slate-200 hover:bg-slate-300 text-slate-800 rounded-lg font-semibold transition-colors cursor-pointer"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
