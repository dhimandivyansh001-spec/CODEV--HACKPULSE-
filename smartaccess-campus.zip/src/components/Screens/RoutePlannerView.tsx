import React, { useState } from 'react';
import {
  MapPin,
  ArrowRight,
  RotateCcw,
  CheckCircle2,
  Clock,
  Sparkles,
  Layers,
  ChevronDown,
  X,
  Volume2,
  Eye,
  ShieldCheck,
} from 'lucide-react';
import { SAMPLE_ROUTE_STEPS } from '../../data/mockCampusData';
import { AccessibilityMode, DesignTokenCustomizer } from '../../types/tokens';

interface RoutePlannerViewProps {
  initialDestination?: string;
  onNavigateToMap: () => void;
  tokenConfig: DesignTokenCustomizer;
}

export const RoutePlannerView: React.FC<RoutePlannerViewProps> = ({
  initialDestination = 'Computer Lab (Block B)',
  onNavigateToMap,
  tokenConfig,
}) => {
  const [fromLocation, setFromLocation] = useState('Main Gate');
  const [toLocation, setToLocation] = useState(initialDestination);
  const [mode, setMode] = useState<AccessibilityMode>('wheelchair');
  const [isCalculated, setIsCalculated] = useState(true);

  const steps = SAMPLE_ROUTE_STEPS;

  return (
    <div className="max-w-3xl mx-auto space-y-6">
      {/* Screen Title */}
      <div className="flex items-center justify-between pb-3 border-b border-slate-200">
        <div>
          <h2 className="text-xl font-bold text-slate-900 tracking-tight">
            Plan Your Route
          </h2>
          <p className="text-xs text-slate-500">
            Intelligent barrier-free pathfinding with audio and ramp prioritization
          </p>
        </div>
        <button
          onClick={() => {
            setFromLocation('Main Gate');
            setToLocation('Computer Lab (Block B)');
            setMode('wheelchair');
          }}
          className="text-xs text-slate-500 hover:text-slate-800 flex items-center gap-1"
        >
          <RotateCcw className="w-3 h-3" />
          <span>Reset</span>
        </button>
      </div>

      {/* Origin & Destination Inputs Card */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs space-y-4">
        {/* Origin */}
        <div className="relative">
          <label className="text-[11px] uppercase font-bold text-slate-400 block mb-1">
            From Location
          </label>
          <div className="relative flex items-center">
            <MapPin className="w-4 h-4 text-rose-500 absolute left-3.5" />
            <input
              type="text"
              value={fromLocation}
              onChange={(e) => setFromLocation(e.target.value)}
              className="w-full pl-10 pr-9 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-800 focus:outline-hidden focus:ring-2 focus:ring-blue-500 focus:bg-white"
            />
            {fromLocation && (
              <button
                onClick={() => setFromLocation('')}
                className="absolute right-3 p-0.5 text-slate-400 hover:text-slate-600"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>
        </div>

        {/* Destination */}
        <div className="relative">
          <label className="text-[11px] uppercase font-bold text-slate-400 block mb-1">
            To Destination
          </label>
          <div className="relative flex items-center">
            <MapPin className="w-4 h-4 text-blue-600 absolute left-3.5" />
            <input
              type="text"
              value={toLocation}
              onChange={(e) => setToLocation(e.target.value)}
              className="w-full pl-10 pr-9 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-800 focus:outline-hidden focus:ring-2 focus:ring-blue-500 focus:bg-white"
            />
            {toLocation && (
              <button
                onClick={() => setToLocation('')}
                className="absolute right-3 p-0.5 text-slate-400 hover:text-slate-600"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>
        </div>

        {/* Accessibility Preference Selector (Matching photo) */}
        <div>
          <label className="text-[11px] uppercase font-bold text-slate-400 block mb-2">
            Accessibility Preference
          </label>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
            {[
              {
                id: 'wheelchair',
                label: 'Wheelchair',
                desc: 'Ramps & lifts only',
                color: 'border-blue-500 bg-blue-50/70 text-blue-700',
                activeColor: 'bg-blue-600 text-white',
              },
              {
                id: 'no-stairs',
                label: 'No Stairs',
                desc: 'Zero steps',
                color: 'border-purple-500 bg-purple-50/70 text-purple-700',
                activeColor: 'bg-purple-600 text-white',
              },
              {
                id: 'visual',
                label: 'Visual Assistance',
                desc: 'Tactile paving',
                color: 'border-emerald-500 bg-emerald-50/70 text-emerald-700',
                activeColor: 'bg-emerald-600 text-white',
              },
              {
                id: 'normal',
                label: 'Normal',
                desc: 'Shortest path',
                color: 'border-slate-500 bg-slate-100 text-slate-700',
                activeColor: 'bg-slate-800 text-white',
              },
            ].map((pref) => {
              const isSelected = mode === pref.id;
              return (
                <button
                  key={pref.id}
                  onClick={() => setMode(pref.id as AccessibilityMode)}
                  className={`p-3 rounded-xl border text-left transition-all cursor-pointer ${
                    isSelected
                      ? `${pref.activeColor} shadow-sm border-transparent`
                      : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
                  }`}
                >
                  <div className="font-bold text-xs">{pref.label}</div>
                  <div
                    className={`text-[10px] mt-0.5 ${
                      isSelected ? 'text-white/80' : 'text-slate-400'
                    }`}
                  >
                    {pref.desc}
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Find Route Button */}
        <button
          onClick={() => setIsCalculated(true)}
          className="w-full py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-xl font-bold text-xs flex items-center justify-center gap-2 shadow-xs transition-all cursor-pointer"
        >
          <span>Find Accessible Route</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>

      {/* Suggested Route Card (Matching photo) */}
      {isCalculated && (
        <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
          {/* Header Summary */}
          <div className="p-5 border-b border-slate-100 bg-slate-50/50 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <span className="text-[10px] uppercase font-bold text-slate-400 block">
                Suggested Route
              </span>
              <h3 className="text-base font-bold text-slate-900 mt-0.5">
                Main Gate → {toLocation}
              </h3>
            </div>

            <div className="flex items-center gap-3">
              <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-emerald-50 text-emerald-700 border border-emerald-200">
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>Accessible Route</span>
              </span>

              <div className="text-right">
                <span className="text-sm font-bold text-slate-900 font-mono">~ 8 min</span>
                <span className="text-xs text-slate-400 block font-mono">350 m</span>
              </div>
            </div>
          </div>

          {/* Step Timeline */}
          <div className="p-6 space-y-4">
            {steps.map((step, idx) => (
              <div key={idx} className="flex items-start gap-4 relative">
                {/* Connector Line */}
                {idx !== steps.length - 1 && (
                  <div className="absolute left-4 top-8 bottom-0 w-0.5 bg-blue-200" />
                )}

                {/* Circle Icon Badge */}
                <div
                  className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold font-mono shrink-0 shadow-xs ${
                    idx === 0
                      ? 'bg-rose-500 text-white'
                      : idx === steps.length - 1
                      ? 'bg-blue-600 text-white'
                      : 'bg-white border-2 border-blue-500 text-blue-700'
                  }`}
                >
                  {step.stepNumber}
                </div>

                {/* Step Details */}
                <div className="flex-1 pb-4">
                  <div className="flex items-baseline justify-between">
                    <span className="text-xs font-bold text-slate-900">
                      {step.location}
                    </span>
                    <span className="text-[11px] font-mono text-slate-400">
                      {step.distanceMeters}m
                    </span>
                  </div>
                  <p className="text-xs text-slate-600 mt-0.5 leading-relaxed">
                    {step.instruction}
                  </p>
                </div>
              </div>
            ))}
          </div>

          {/* Route Footer Action */}
          <div className="p-4 border-t border-slate-100 bg-slate-50 flex items-center justify-between">
            <div className="text-xs text-slate-500 flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-emerald-600" />
              <span>Verified barrier-free: 0 steps, 2 ADA ramps, 1 working elevator</span>
            </div>
            <button
              onClick={onNavigateToMap}
              className="text-xs font-bold text-blue-600 hover:text-blue-800 flex items-center gap-1 cursor-pointer"
            >
              <span>View Route on Campus Map</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
