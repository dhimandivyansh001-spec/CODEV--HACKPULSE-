import React, { useState } from 'react';
import {
  Send,
  Sparkles,
  Bot,
  User,
  ArrowRight,
  HelpCircle,
  Compass,
  MessageSquare,
  ShieldCheck,
} from 'lucide-react';
import { AI_KNOWLEDGE_BASE } from '../../data/mockCampusData';
import { DesignTokenCustomizer } from '../../types/tokens';

interface AiAssistantViewProps {
  onNavigateToRoute: () => void;
  tokenConfig: DesignTokenCustomizer;
}

interface Message {
  id: string;
  sender: 'user' | 'assistant';
  text: string;
  routeLink?: string;
  timestamp: string;
}

export const AiAssistantView: React.FC<AiAssistantViewProps> = ({
  onNavigateToRoute,
  tokenConfig,
}) => {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 'm1',
      sender: 'user',
      text: 'How can I reach the library without stairs?',
      timestamp: '10:42 AM',
    },
    {
      id: 'm2',
      sender: 'assistant',
      text: 'You can reach the library using the accessible route:\n1. Start from Main Gate\n2. Use Ramp A\n3. Take Lift A to the 1st floor\n4. Follow the signs to the Library.\n\nThis route avoids all stairs and is wheelchair friendly.',
      routeLink: 'Main Gate → Ramp A → Lift A → Library',
      timestamp: '10:42 AM',
    },
  ]);

  const [inputVal, setInputVal] = useState('');

  const exampleQuestions = [
    'Where is the nearest accessible toilet?',
    'How do I reach Block B without stairs?',
    'Is the lift near the library working?',
    'Which entrance is wheelchair accessible?',
  ];

  const handleSend = (textToSend?: string) => {
    const query = (textToSend || inputVal).trim();
    if (!query) return;

    const userMsg: Message = {
      id: Date.now().toString(),
      sender: 'user',
      text: query,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, userMsg]);
    setInputVal('');

    // Answer matching
    setTimeout(() => {
      const qLower = query.toLowerCase();
      let matched = AI_KNOWLEDGE_BASE.find((item) =>
        qLower.includes(item.trigger)
      );

      const assistantMsg: Message = {
        id: (Date.now() + 1).toString(),
        sender: 'assistant',
        text: matched
          ? matched.answer
          : `I have scanned the latest campus telemetry for "${query}". The recommended accessible path follows tactile outdoor paving with 1:12 ADA ramps and operational automatic sliding doors. All campus elevators along this corridor are verified online.`,
        routeLink: matched?.recommendedRoute,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };

      setMessages((prev) => [...prev, assistantMsg]);
    }, 400);
  };

  return (
    <div className="max-w-4xl mx-auto space-y-4">
      {/* Header */}
      <div className="pb-3 border-b border-slate-200">
        <div className="flex items-center gap-2">
          <div className="w-7 h-7 rounded-lg bg-blue-600 text-white flex items-center justify-center">
            <Bot className="w-4 h-4" />
          </div>
          <h2 className="text-xl font-bold text-slate-900 tracking-tight">
            Campus AI Assistant
          </h2>
        </div>
        <p className="text-xs text-slate-500 mt-1">
          Ask anything about campus facilities, barrier-free routes or accessibility accommodations.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        {/* Chat Conversation Box (8 cols) */}
        <div className="lg:col-span-8 bg-white rounded-2xl border border-slate-200 shadow-xs flex flex-col h-[520px] overflow-hidden">
          {/* Messages Scroll Area */}
          <div className="flex-1 p-5 overflow-y-auto space-y-4 bg-slate-50/40">
            {messages.map((msg) => (
              <div
                key={msg.id}
                className={`flex gap-3 ${
                  msg.sender === 'user' ? 'justify-end' : 'justify-start'
                }`}
              >
                {msg.sender === 'assistant' && (
                  <div className="w-7 h-7 rounded-full bg-blue-600 text-white flex items-center justify-center shrink-0 mt-1">
                    <Sparkles className="w-3.5 h-3.5" />
                  </div>
                )}

                <div
                  className={`max-w-[85%] rounded-2xl p-4 text-xs leading-relaxed ${
                    msg.sender === 'user'
                      ? 'bg-blue-600 text-white rounded-tr-xs shadow-xs'
                      : 'bg-white text-slate-800 border border-slate-200 shadow-xs rounded-tl-xs'
                  }`}
                >
                  <p className="whitespace-pre-line">{msg.text}</p>

                  {/* Route Link Card inside Assistant Bubble */}
                  {msg.routeLink && (
                    <div className="mt-3 p-2.5 rounded-xl bg-blue-50/80 border border-blue-200 flex items-center justify-between text-blue-900">
                      <div className="flex items-center gap-2">
                        <Compass className="w-4 h-4 text-blue-600" />
                        <span className="font-semibold text-[11px]">
                          {msg.routeLink}
                        </span>
                      </div>
                      <button
                        onClick={onNavigateToRoute}
                        className="text-[11px] font-bold text-blue-700 hover:text-blue-900 flex items-center gap-1 cursor-pointer"
                      >
                        <span>View Route</span>
                        <ArrowRight className="w-3 h-3" />
                      </button>
                    </div>
                  )}

                  <div
                    className={`mt-1.5 text-[10px] text-right ${
                      msg.sender === 'user' ? 'text-blue-100' : 'text-slate-400'
                    }`}
                  >
                    {msg.timestamp}
                  </div>
                </div>

                {msg.sender === 'user' && (
                  <div className="w-7 h-7 rounded-full bg-slate-200 text-slate-700 flex items-center justify-center shrink-0 mt-1 text-xs font-bold">
                    You
                  </div>
                )}
              </div>
            ))}
          </div>

          {/* Bottom Chat Input */}
          <div className="p-3 border-t border-slate-200 bg-white">
            <form
              onSubmit={(e) => {
                e.preventDefault();
                handleSend();
              }}
              className="flex items-center gap-2"
            >
              <input
                type="text"
                placeholder="Type your question..."
                value={inputVal}
                onChange={(e) => setInputVal(e.target.value)}
                className="flex-1 py-2.5 px-4 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-800 placeholder-slate-400 focus:outline-hidden focus:ring-2 focus:ring-blue-500 focus:bg-white"
              />
              <button
                type="submit"
                className="p-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl transition-colors cursor-pointer shadow-xs"
                title="Send message"
              >
                <Send className="w-4 h-4" />
              </button>
            </form>
          </div>
        </div>

        {/* Right Sidebar: Example Questions & Help Card (4 cols) */}
        <div className="lg:col-span-4 space-y-4">
          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
            <div className="flex items-center gap-2 text-xs font-bold text-slate-900 mb-3">
              <HelpCircle className="w-4 h-4 text-blue-600" />
              <span>Example Questions</span>
            </div>

            <div className="space-y-2">
              {exampleQuestions.map((q, idx) => (
                <button
                  key={idx}
                  onClick={() => handleSend(q)}
                  className="w-full text-left p-2.5 rounded-xl border border-slate-100 hover:border-blue-200 hover:bg-blue-50/50 text-xs font-medium text-slate-700 transition-colors cursor-pointer group"
                >
                  <span className="group-hover:text-blue-700">{q}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Community Mascot Banner (Matching photo) */}
          <div className="bg-gradient-to-br from-blue-50 to-indigo-50 p-5 rounded-2xl border border-blue-100 text-center space-y-3">
            <div className="w-12 h-12 mx-auto rounded-full bg-blue-600/10 flex items-center justify-center text-blue-600 font-bold text-lg">
              ♿
            </div>
            <div>
              <h4 className="text-sm font-bold text-slate-900">
                Ask anything. We're here to help!
              </h4>
              <p className="text-xs text-slate-600 mt-1">
                Connected directly to smart elevators, door sensors, and campus maps.
              </p>
            </div>
            <div className="pt-1 text-[11px] text-blue-700 font-semibold italic">
              "Accessible Campus, Stronger Community"
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
