import React, { useState } from 'react';
import {
  Menu,
  User,
  Search,
  ArrowRight,
  Compass,
  AlertTriangle,
  Bot,
  MapPin,
  ChevronRight,
  TrendingUp,
  Heart,
  Smartphone,
  Monitor,
} from 'lucide-react';
import { AccessibilityMode, DesignTokenCustomizer } from '../../types/tokens';
import { ActiveScreen } from '../Navigation';

interface MobileHomeViewProps {
  onSelectScreen: (screen: ActiveScreen) => void;
  tokenConfig: DesignTokenCustomizer;
}

export const MobileHomeView: React.FC<MobileHomeViewProps> = ({
  onSelectScreen,
  tokenConfig,
}) => {
  const [selectedMode, setSelectedMode] = useState<AccessibilityMode>('wheelchair');
  const [viewFrame, setViewFrame] = useState<'device' | 'fluid'>('device');
  const [searchQuery, setSearchQuery] = useState('');

  return (
    <div className="space-y-4">
      {/* View Toggle */}
      <div className="flex items-center justify-between pb-2 border-b border-slate-200">
        <div>
          <h2 className="text-xl font-bold text-slate-900 tracking-tight">
            Mobile Experience View
          </h2>
          <p className="text-xs text-slate-500">
            Responsive 390x844 mobile viewport as shown on the right side of the mockup
          </p>
        </div>

        <div className="flex items-center gap-1.5 bg-slate-100 p-1 rounded-xl text-xs">
          <button
            onClick={() => setViewFrame('device')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-medium transition-all ${
              viewFrame === 'device'
                ? 'bg-white text-slate-900 shadow-xs font-semibold'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Smartphone className="w-3.5 h-3.5" />
            <span>Mobile Device (390px)</span>
          </button>
          <button
            onClick={() => setViewFrame('fluid')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-medium transition-all ${
              viewFrame === 'fluid'
                ? 'bg-white text-slate-900 shadow-xs font-semibold'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Monitor className="w-3.5 h-3.5" />
            <span>Expanded View</span>
          </button>
        </div>
      </div>

      {/* Frame Container */}
      <div className="flex justify-center p-2 sm:p-6 bg-slate-100/70 rounded-2xl border border-slate-200">
        <div
          className={`bg-white rounded-3xl shadow-xl border border-slate-300 overflow-hidden flex flex-col transition-all duration-300 ${
            viewFrame === 'device'
              ? 'w-full max-w-[390px] min-h-[780px]'
              : 'w-full max-w-2xl min-h-[600px]'
          }`}
        >
          {/* Mobile Top Bar */}
          <div className="px-5 py-4 flex items-center justify-between border-b border-slate-100 bg-white sticky top-0 z-10">
            <button className="p-1 rounded-lg text-slate-700 hover:bg-slate-100">
              <Menu className="w-5 h-5" />
            </button>
            <div className="flex items-center gap-2">
              <div className="w-6 h-6 rounded-md bg-blue-600 text-white flex items-center justify-center font-bold text-xs">
                ♿
              </div>
              <span className="font-bold text-sm text-slate-900">
                SmartAccess Campus
              </span>
            </div>
            <div className="w-8 h-8 rounded-full bg-slate-100 border border-slate-200 flex items-center justify-center text-slate-600">
              <User className="w-4 h-4" />
            </div>
          </div>

          {/* Scrollable Content */}
          <div className="flex-1 overflow-y-auto p-5 space-y-5">
            {/* Hero Welcome */}
            <div className="space-y-1">
              <h1 className="text-xl font-extrabold text-slate-900 tracking-tight leading-tight">
                Navigate your campus.
                <br />
                <span className="text-blue-600">Your way.</span>
              </h1>
              <p className="text-xs text-slate-500 leading-relaxed">
                An inclusive campus navigation platform for everyone, everywhere.
              </p>
            </div>

            {/* Quick Search */}
            <div className="relative flex items-center">
              <Search className="w-4 h-4 text-slate-400 absolute left-3.5" />
              <input
                type="text"
                placeholder="Search building, room or facility..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-9 pr-11 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-800 placeholder-slate-400 focus:outline-hidden focus:ring-2 focus:ring-blue-500 focus:bg-white"
              />
              <button
                onClick={() => onSelectScreen('map')}
                className="absolute right-2 p-1.5 rounded-lg bg-blue-600 text-white shadow-xs"
              >
                <ArrowRight className="w-3 h-3" />
              </button>
            </div>

            {/* Choose Accessibility Mode */}
            <div>
              <div className="text-xs font-bold text-slate-900 mb-2.5">
                Choose Accessibility Mode
              </div>
              <div className="grid grid-cols-4 gap-2 text-center">
                {[
                  { id: 'wheelchair', label: 'Wheelchair', icon: '♿', activeBg: 'bg-blue-600 text-white' },
                  { id: 'no-stairs', label: 'No Stairs', icon: '⚡', activeBg: 'bg-purple-600 text-white' },
                  { id: 'visual', label: 'Visual Assist', icon: '👁️', activeBg: 'bg-emerald-600 text-white' },
                  { id: 'normal', label: 'Normal', icon: '🚶', activeBg: 'bg-slate-800 text-white' },
                ].map((m) => {
                  const isActive = selectedMode === m.id;
                  return (
                    <button
                      key={m.id}
                      onClick={() => setSelectedMode(m.id as AccessibilityMode)}
                      className={`p-2.5 rounded-xl border flex flex-col items-center justify-center transition-all cursor-pointer ${
                        isActive
                          ? `${m.activeBg} border-transparent shadow-xs`
                          : 'bg-slate-50/70 border-slate-200 text-slate-700 hover:bg-slate-100'
                      }`}
                    >
                      <span className="text-base mb-1">{m.icon}</span>
                      <span className="text-[10px] font-bold line-clamp-1">
                        {m.label}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* 3 Main Action List Cards (Matching photo) */}
            <div className="space-y-2.5">
              {/* Explore Campus */}
              <button
                onClick={() => onSelectScreen('map')}
                className="w-full p-3.5 bg-white rounded-xl border border-slate-200 hover:border-blue-300 hover:shadow-xs flex items-center justify-between text-left transition-all cursor-pointer group"
              >
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-lg bg-blue-50 text-blue-600 flex items-center justify-center">
                    <Compass className="w-5 h-5" />
                  </div>
                  <div>
                    <span className="text-xs font-bold text-slate-900 block group-hover:text-blue-600">
                      Explore Campus
                    </span>
                    <span className="text-[11px] text-slate-500">
                      View map, buildings & facilities
                    </span>
                  </div>
                </div>
                <ChevronRight className="w-4 h-4 text-slate-400 group-hover:translate-x-0.5 transition-transform" />
              </button>

              {/* Report an Issue */}
              <button
                onClick={() => onSelectScreen('report')}
                className="w-full p-3.5 bg-white rounded-xl border border-slate-200 hover:border-rose-300 hover:shadow-xs flex items-center justify-between text-left transition-all cursor-pointer group"
              >
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-lg bg-rose-50 text-rose-600 flex items-center justify-center">
                    <AlertTriangle className="w-5 h-5" />
                  </div>
                  <div>
                    <span className="text-xs font-bold text-slate-900 block group-hover:text-rose-600">
                      Report an Issue
                    </span>
                    <span className="text-[11px] text-slate-500">
                      Help us keep the campus accessible
                    </span>
                  </div>
                </div>
                <ChevronRight className="w-4 h-4 text-slate-400 group-hover:translate-x-0.5 transition-transform" />
              </button>

              {/* Ask Campus AI */}
              <button
                onClick={() => onSelectScreen('ai')}
                className="w-full p-3.5 bg-white rounded-xl border border-slate-200 hover:border-purple-300 hover:shadow-xs flex items-center justify-between text-left transition-all cursor-pointer group"
              >
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-lg bg-purple-50 text-purple-600 flex items-center justify-center">
                    <Bot className="w-5 h-5" />
                  </div>
                  <div>
                    <span className="text-xs font-bold text-slate-900 block group-hover:text-purple-600">
                      Ask Campus AI
                    </span>
                    <span className="text-[11px] text-slate-500">
                      Get instant route & elevator answers
                    </span>
                  </div>
                </div>
                <ChevronRight className="w-4 h-4 text-slate-400 group-hover:translate-x-0.5 transition-transform" />
              </button>
            </div>

            {/* Bottom Mascot Slogan Card (Matching photo) */}
            <div className="p-4 rounded-xl bg-linear-to-r from-blue-500 to-indigo-600 text-white text-center space-y-1">
              <div className="text-xs font-bold tracking-tight">
                Accessible Campus, Stronger Community
              </div>
              <p className="text-[11px] text-blue-100">
                Better Access, Brighter Futures 💙
              </p>
            </div>
          </div>

          {/* Bottom Tab Bar (Matching photo: Home, Map, Route, Report, Profile) */}
          <div className="px-3 py-2 border-t border-slate-100 bg-white grid grid-cols-5 gap-1 text-center">
            <button
              onClick={() => onSelectScreen('mobile')}
              className="flex flex-col items-center py-1 text-blue-600 cursor-pointer"
            >
              <Compass className="w-4 h-4" />
              <span className="text-[10px] font-bold mt-0.5">Home</span>
            </button>
            <button
              onClick={() => onSelectScreen('map')}
              className="flex flex-col items-center py-1 text-slate-500 hover:text-slate-900 cursor-pointer"
            >
              <MapPin className="w-4 h-4" />
              <span className="text-[10px] font-medium mt-0.5">Map</span>
            </button>
            <button
              onClick={() => onSelectScreen('route')}
              className="flex flex-col items-center py-1 text-slate-500 hover:text-slate-900 cursor-pointer"
            >
              <TrendingUp className="w-4 h-4" />
              <span className="text-[10px] font-medium mt-0.5">Route</span>
            </button>
            <button
              onClick={() => onSelectScreen('report')}
              className="flex flex-col items-center py-1 text-slate-500 hover:text-slate-900 cursor-pointer"
            >
              <AlertTriangle className="w-4 h-4" />
              <span className="text-[10px] font-medium mt-0.5">Report</span>
            </button>
            <button
              onClick={() => onSelectScreen('dashboard')}
              className="flex flex-col items-center py-1 text-slate-500 hover:text-slate-900 cursor-pointer"
            >
              <User className="w-4 h-4" />
              <span className="text-[10px] font-medium mt-0.5">Admin</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
