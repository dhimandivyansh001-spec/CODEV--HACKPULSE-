import React, { useState } from 'react';
import {
  Palette,
  Check,
  Copy,
  Info,
  CheckCircle2,
  AlertTriangle,
  ArrowUpDown,
  TrendingUp,
  DoorOpen,
  MapPin,
  Sparkles,
  Sliders,
  SlidersHorizontal,
} from 'lucide-react';
import { DesignTokenCustomizer } from '../../types/tokens';

interface DesignTokensViewProps {
  tokenConfig: DesignTokenCustomizer;
  onUpdateTokenConfig: (newConfig: Partial<DesignTokenCustomizer>) => void;
  onOpenPromptModal: () => void;
}

export const DesignTokensView: React.FC<DesignTokensViewProps> = ({
  tokenConfig,
  onUpdateTokenConfig,
  onOpenPromptModal,
}) => {
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  const handleCopy = (text: string, key: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(key);
    setTimeout(() => setCopiedKey(null), 1800);
  };

  const colorTokens = [
    {
      name: 'Brand Primary (Wheelchair)',
      token: 'color.brand.primary.600',
      hex: tokenConfig.primaryColor,
      role: 'Primary action button, active navigation, wheelchair route waypoints',
      contrast: 'WCAG AAA (7.2:1)',
    },
    {
      name: 'Accessible Violet (No Stairs)',
      token: 'color.mode.no-stairs',
      hex: '#8B5CF6',
      role: 'Step-free route corridors, elevators, and automated doors',
      contrast: 'WCAG AA (4.8:1)',
    },
    {
      name: 'High-Contrast Emerald (Visual)',
      token: 'color.mode.visual-assist',
      hex: '#059669',
      role: 'Tactile paving routes, audio signals, high-contrast markers',
      contrast: 'WCAG AAA (7.1:1)',
    },
    {
      name: 'Warning Amber (Partial/Underway)',
      token: 'color.status.warning',
      hex: '#F59E0B',
      role: 'Elevator maintenance, temporary route re-routing',
      contrast: 'WCAG AA (3.2:1 on dark)',
    },
    {
      name: 'Hazard Crimson (Blocked/Critical)',
      token: 'color.status.danger',
      hex: '#EF4444',
      role: 'Blocked ramps, locked doors, out-of-order equipment',
      contrast: 'WCAG AA (4.6:1)',
    },
    {
      name: 'Canvas Background',
      token: 'color.surface.canvas',
      hex: '#F8FAFC',
      role: 'Neutral 60% viewport background canvas',
      contrast: 'Dominant Light',
    },
    {
      name: 'Card Surface',
      token: 'color.surface.card',
      hex: '#FFFFFF',
      role: '30% structural surfaces with 1px hairline border',
      contrast: 'Structural',
    },
    {
      name: 'Text Primary',
      token: 'color.text.primary',
      hex: '#0F172A',
      role: 'Display headings and high-priority tabular figures',
      contrast: 'WCAG AAA (15.8:1)',
    },
  ];

  const iconsReference = [
    { name: 'Wheelchair', symbol: '♿', icon: 'Accessibility', role: 'Wheelchair mode selector & ramp paths' },
    { name: 'Lift / Elevator', symbol: '🛗', icon: 'ArrowUpDown', role: 'Elevator waypoints & vertical transit' },
    { name: 'Ramp (ADA)', symbol: '📐', icon: 'TrendingUp', role: '1:12 ADA slope connectors' },
    { name: 'Accessible Toilet', symbol: '🚻', icon: 'DoorOpen', role: 'Restrooms with dual grab bars' },
    { name: 'Entrance', symbol: '🚪', icon: 'DoorOpen', role: 'Zero-threshold automated entrance' },
    { name: 'Location Pin', symbol: '📍', icon: 'MapPin', role: 'Current position & destination marker' },
    { name: 'Warning', symbol: '⚠️', icon: 'AlertTriangle', role: 'Active obstacle or partial closure' },
    { name: 'Success', symbol: '✅', icon: 'CheckCircle2', role: '100% verified accessible route' },
    { name: 'Info', symbol: 'ℹ️', icon: 'Info', role: 'Facility instructions and audio aids' },
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-200">
        <div>
          <h2 className="text-xl font-bold text-slate-900 tracking-tight flex items-center gap-2">
            <Palette className="w-5 h-5 text-blue-600" />
            <span>Design Tokens & Iconography Reference</span>
          </h2>
          <p className="text-xs text-slate-500">
            Structured design variables matching the bottom-right panel of the project blueprint
          </p>
        </div>

        <button
          onClick={onOpenPromptModal}
          className="px-3.5 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-semibold flex items-center gap-1.5 shadow-xs transition-colors cursor-pointer"
        >
          <Sparkles className="w-3.5 h-3.5" />
          <span>Export to Figma Tokens</span>
        </button>
      </div>

      {/* Live Token Playground */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <SlidersHorizontal className="w-4 h-4 text-blue-600" />
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-900">
              Live Token Customizer (Updates all screens in real-time)
            </h3>
          </div>
          <span className="text-[11px] text-slate-400 font-mono">
            Synced with Figma prompt generator
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 pt-1">
          {/* Brand Primary Customizer */}
          <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
            <span className="text-xs font-bold text-slate-800 block mb-2">
              Primary Brand Accent
            </span>
            <div className="flex items-center gap-2">
              {[
                { hex: '#2563EB', name: 'Campus Blue' },
                { hex: '#4F46E5', name: 'Indigo' },
                { hex: '#059669', name: 'Emerald' },
                { hex: '#7C3AED', name: 'Violet' },
              ].map((c) => (
                <button
                  key={c.hex}
                  onClick={() =>
                    onUpdateTokenConfig({ primaryColor: c.hex, primaryName: c.name })
                  }
                  className={`w-7 h-7 rounded-lg transition-transform ${
                    tokenConfig.primaryColor === c.hex
                      ? 'ring-2 ring-blue-500 ring-offset-2 scale-110'
                      : 'opacity-80 hover:opacity-100'
                  }`}
                  style={{ backgroundColor: c.hex }}
                  title={c.name}
                />
              ))}
            </div>
            <span className="text-[11px] text-slate-500 block mt-2 font-mono">
              {tokenConfig.primaryColor} ({tokenConfig.primaryName})
            </span>
          </div>

          {/* Corner Radius Customizer */}
          <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
            <span className="text-xs font-bold text-slate-800 block mb-2">
              Border Radius Token
            </span>
            <div className="grid grid-cols-4 gap-1">
              {[
                { px: 4, label: '4px' },
                { px: 8, label: '8px' },
                { px: 12, label: '12px' },
                { px: 16, label: '16px' },
              ].map((r) => (
                <button
                  key={r.px}
                  onClick={() => onUpdateTokenConfig({ radiusPx: r.px })}
                  className={`py-1 rounded text-xs font-semibold transition-all ${
                    tokenConfig.radiusPx === r.px
                      ? 'bg-blue-600 text-white shadow-xs'
                      : 'bg-white border border-slate-200 text-slate-700 hover:bg-slate-100'
                  }`}
                >
                  {r.label}
                </button>
              ))}
            </div>
            <span className="text-[11px] text-slate-500 block mt-2 font-mono">
              radius/card: {tokenConfig.radiusPx}px
            </span>
          </div>

          {/* Typography Scale */}
          <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
            <span className="text-xs font-bold text-slate-800 block mb-2">
              Font Family Binding
            </span>
            <div className="text-xs text-slate-800 font-semibold">
              Plus Jakarta Sans
            </div>
            <span className="text-[11px] text-slate-500 block mt-1 font-mono">
              Metrics: JetBrains Mono
            </span>
            <div className="mt-2 text-[10px] text-emerald-600 font-medium">
              ✓ Tabular-nums enabled
            </div>
          </div>

          {/* WCAG Compliance */}
          <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
            <span className="text-xs font-bold text-slate-800 block mb-2">
              Accessibility Standard
            </span>
            <div className="text-xs text-emerald-700 font-bold flex items-center gap-1.5">
              <CheckCircle2 className="w-4 h-4 text-emerald-600" />
              <span>WCAG 2.1 AA & AAA</span>
            </div>
            <span className="text-[11px] text-slate-500 block mt-1">
              Color-blind safe palette
            </span>
            <div className="mt-2 text-[10px] text-slate-400">
              Zero state signaled by hue alone
            </div>
          </div>
        </div>
      </div>

      {/* Color Swatches Grid (Matching bottom-right of photo) */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs space-y-4">
        <h3 className="text-sm font-bold text-slate-900">
          Color Tokens & Semantic Roles
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
          {colorTokens.map((item) => (
            <div
              key={item.token}
              className="p-3.5 rounded-xl border border-slate-200/80 hover:border-slate-300 transition-all space-y-2 group"
            >
              <div
                className="h-14 w-full rounded-lg border border-black/5 shadow-inner transition-transform group-hover:scale-[1.02]"
                style={{ backgroundColor: item.hex }}
              />
              <div>
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-slate-900">
                    {item.name}
                  </span>
                  <button
                    onClick={() => handleCopy(item.hex, item.token)}
                    className="p-1 rounded text-slate-400 hover:text-slate-700 transition-colors cursor-pointer"
                    title="Copy HEX"
                  >
                    {copiedKey === item.token ? (
                      <Check className="w-3.5 h-3.5 text-emerald-600" />
                    ) : (
                      <Copy className="w-3.5 h-3.5" />
                    )}
                  </button>
                </div>
                <div className="font-mono text-[11px] text-slate-500 mt-0.5">
                  {item.hex} · {item.token}
                </div>
                <p className="text-[11px] text-slate-600 mt-1 line-clamp-2">
                  {item.role}
                </p>
                <div className="pt-1.5 flex items-center justify-between text-[10px] text-slate-400 border-t border-slate-100 mt-2">
                  <span>Contrast:</span>
                  <span className="font-semibold text-slate-700">{item.contrast}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Iconography Reference (Matching bottom-right of photo) */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs space-y-4">
        <h3 className="text-sm font-bold text-slate-900">
          Icons Reference & Component Markers
        </h3>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-9 gap-3 text-center">
          {iconsReference.map((ic, idx) => (
            <div
              key={idx}
              className="p-3 rounded-xl bg-slate-50 border border-slate-200/80 hover:bg-white hover:border-blue-300 hover:shadow-xs transition-all"
            >
              <div className="text-2xl mb-1.5">{ic.symbol}</div>
              <div className="text-xs font-bold text-slate-900 line-clamp-1">
                {ic.name}
              </div>
              <div className="text-[10px] text-slate-500 mt-0.5 line-clamp-2">
                {ic.role}
              </div>
            </div>
          ))}
        </div>

        {/* Motto Banner from image */}
        <div className="pt-3 text-center">
          <span className="text-sm font-bold text-blue-600 italic">
            Better Access, Brighter Futures 💙
          </span>
        </div>
      </div>
    </div>
  );
};
