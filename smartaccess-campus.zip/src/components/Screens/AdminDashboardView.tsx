import React, { useState } from 'react';
import {
  AlertCircle,
  Users,
  CheckCircle2,
  TrendingUp,
  ArrowUpRight,
  Filter,
  Search,
  Wrench,
  Check,
  Building2,
  Clock,
  Sparkles,
  ChevronRight,
  ArrowUpDown,
  DoorOpen,
} from 'lucide-react';
import { CampusIssue, FacilityStatus, DesignTokenCustomizer } from '../../types/tokens';

interface AdminDashboardViewProps {
  issues: CampusIssue[];
  facilities: FacilityStatus[];
  onResolveIssue: (id: string) => void;
  onNavigateToReport: () => void;
  onNavigateToMap: () => void;
  tokenConfig: DesignTokenCustomizer;
}

export const AdminDashboardView: React.FC<AdminDashboardViewProps> = ({
  issues,
  facilities,
  onResolveIssue,
  onNavigateToReport,
  onNavigateToMap,
  tokenConfig,
}) => {
  const [filterType, setFilterType] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');

  // Active metrics calculations
  const pendingCount = issues.filter((i) => i.status !== 'resolved').length;
  const highSeverityCount = issues.filter(
    (i) => i.status !== 'resolved' && i.severity === 'high'
  ).length;

  const lifts = facilities.find((f) => f.id === 'fac-lifts') || {
    operational: 7,
    total: 8,
  };
  const ramps = facilities.find((f) => f.id === 'fac-ramps') || {
    operational: 6,
    total: 7,
  };
  const toilets = facilities.find((f) => f.id === 'fac-toilets') || {
    operational: 4,
    total: 5,
  };

  // Dynamic accessibility score based on operational facilities & open issues
  const accessibilityScore = Math.max(
    50,
    Math.min(99, Math.round(78 + (issues.length - pendingCount) * 2 - highSeverityCount * 3))
  );

  const filteredIssues = issues.filter((issue) => {
    const matchesType = filterType === 'all' || issue.type === filterType;
    const matchesSearch =
      issue.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      issue.location.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesType && matchesSearch;
  });

  // 7-day trend data
  const trendPoints = [
    { day: 'Mon', count: 8 },
    { day: 'Tue', count: 12 },
    { day: 'Wed', count: 10 },
    { day: 'Thu', count: 11 },
    { day: 'Fri', count: 15 },
    { day: 'Sat', count: 13 },
    { day: 'Sun', count: pendingCount },
  ];

  return (
    <div className="space-y-6">
      {/* SaaS Admin Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 pb-4 border-b border-slate-200">
        <div>
          <div className="flex items-center gap-2 text-xs font-semibold text-slate-500 uppercase tracking-wider">
            <span>SaaS Admin Console</span>
            <span>·</span>
            <span>Live Campus Telemetry</span>
          </div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900 mt-0.5">
            Admin Dashboard
          </h1>
          <p className="text-xs text-slate-500">
            Good morning, Admin! System operating normally across 5 active campus zones.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <div className="text-right hidden sm:block">
            <div className="text-xs font-semibold text-slate-900">Thu, 3 Oct 2026</div>
            <div className="text-[11px] text-slate-500">Academic Term 1</div>
          </div>
          <button
            onClick={onNavigateToReport}
            className="px-3.5 py-2 text-xs font-semibold text-white rounded-lg shadow-xs hover:shadow transition-all flex items-center gap-2 cursor-pointer"
            style={{ backgroundColor: tokenConfig.primaryColor }}
          >
            <AlertCircle className="w-3.5 h-3.5" />
            <span>+ Log Campus Issue</span>
          </button>
        </div>
      </div>

      {/* Row 1: 4 KPI Cards (Directly matching photo) */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* KPI 1: Reported Issues */}
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs hover:border-slate-300 transition-all">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-600">Reported Issues</span>
            <div className="w-8 h-8 rounded-lg bg-rose-50 flex items-center justify-center text-rose-600">
              <AlertCircle className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-3xl font-extrabold text-slate-900 font-mono tabular-nums">
              {pendingCount}
            </span>
            <span className="text-xs text-rose-600 font-medium font-mono">
              {highSeverityCount} high priority
            </span>
          </div>
          <div className="mt-2 text-xs text-slate-500">
            Open accessibility hazards
          </div>
        </div>

        {/* KPI 2: Active Users */}
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs hover:border-slate-300 transition-all">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-600">Active Users</span>
            <div className="w-8 h-8 rounded-lg bg-amber-50 flex items-center justify-center text-amber-600">
              <Users className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-3xl font-extrabold text-slate-900 font-mono tabular-nums">
              5
            </span>
            <span className="text-xs text-emerald-600 font-medium flex items-center">
              <ArrowUpRight className="w-3 h-3" /> Live
            </span>
          </div>
          <div className="mt-2 text-xs text-slate-500">
            Visitors navigating via app right now
          </div>
        </div>

        {/* KPI 3: Working Lifts */}
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs hover:border-slate-300 transition-all">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-600">Working Lifts</span>
            <div className="w-8 h-8 rounded-lg bg-emerald-50 flex items-center justify-center text-emerald-600">
              <ArrowUpDown className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-3xl font-extrabold text-slate-900 font-mono tabular-nums">
              {lifts.operational} / {lifts.total}
            </span>
            <span className="text-xs text-emerald-600 font-medium">
              87.5%
            </span>
          </div>
          <div className="mt-2 text-xs text-slate-500">
            Lift 2 (Bld A) in inspection
          </div>
        </div>

        {/* KPI 4: Accessible Ramps */}
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs hover:border-slate-300 transition-all">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-600">Accessible Ramps</span>
            <div className="w-8 h-8 rounded-lg bg-purple-50 flex items-center justify-center text-purple-600">
              <TrendingUp className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-3xl font-extrabold text-slate-900 font-mono tabular-nums">
              {ramps.operational} / {ramps.total}
            </span>
            <span className="text-xs text-purple-600 font-medium">
              85.7%
            </span>
          </div>
          <div className="mt-2 text-xs text-slate-500">
            Library Ramp clearance needed
          </div>
        </div>
      </div>

      {/* Row 2: Accessibility Score Donut + Issues Trend Chart + Most Reported Locations */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        {/* Left Column (Score + Trend) - 7 cols */}
        <div className="lg:col-span-7 space-y-5">
          {/* Accessibility Score Card */}
          <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-xs">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-sm font-bold text-slate-900">Campus Accessibility Score</h3>
              <span className="text-xs text-slate-500">Calculated in real-time</span>
            </div>

            <div className="flex flex-col sm:flex-row items-center gap-6">
              {/* Circular Gauge */}
              <div className="relative w-36 h-36 flex items-center justify-center shrink-0">
                <svg className="w-full h-full transform -rotate-90" viewBox="0 0 100 100">
                  <circle
                    cx="50"
                    cy="50"
                    r="40"
                    stroke="#E2E8F0"
                    strokeWidth="10"
                    fill="transparent"
                  />
                  <circle
                    cx="50"
                    cy="50"
                    r="40"
                    stroke="#10B981"
                    strokeWidth="10"
                    fill="transparent"
                    strokeDasharray="251.2"
                    strokeDashoffset={251.2 * (1 - accessibilityScore / 100)}
                    strokeLinecap="round"
                    className="transition-all duration-700 ease-out"
                  />
                </svg>
                <div className="absolute flex flex-col items-center justify-center">
                  <span className="text-2xl font-black text-slate-900 font-mono tabular-nums">
                    {accessibilityScore}%
                  </span>
                  <span className="text-[10px] font-semibold text-emerald-600 uppercase">
                    Good
                  </span>
                </div>
              </div>

              {/* Score breakdown description */}
              <div className="space-y-2 text-center sm:text-left">
                <div className="text-sm font-semibold text-slate-800">
                  Overall campus accessibility is good. Keep improving!
                </div>
                <p className="text-xs text-slate-500 leading-relaxed">
                  Based on operational elevator uptime (87.5%), unobstructed ADA ramps (85.7%), and automated doors. Resolving the 2 high-priority obstacles in Building A will lift the score to 84%.
                </p>
                <div className="pt-2 flex flex-wrap gap-2 text-[11px] text-slate-600">
                  <span className="px-2 py-0.5 bg-slate-100 rounded text-slate-700">
                    ADA Compliant: 92%
                  </span>
                  <span className="px-2 py-0.5 bg-slate-100 rounded text-slate-700">
                    Tactile Paving: 98%
                  </span>
                  <span className="px-2 py-0.5 bg-slate-100 rounded text-slate-700">
                    Voice Elevators: 88%
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* Issues Trend Chart */}
          <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-xs">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h3 className="text-sm font-bold text-slate-900">Issues Trend (Last 7 Days)</h3>
                <p className="text-xs text-slate-500">Report volume by day</p>
              </div>
              <span className="text-xs font-mono text-slate-500">Avg 11.4 / day</span>
            </div>

            {/* SVG Trendline Chart */}
            <div className="h-44 w-full">
              <svg className="w-full h-full" viewBox="0 0 500 160" preserveAspectRatio="none">
                {/* Horizontal grid lines */}
                <line x1="0" y1="40" x2="500" y2="40" stroke="#F1F5F9" strokeWidth="1" />
                <line x1="0" y1="80" x2="500" y2="80" stroke="#F1F5F9" strokeWidth="1" />
                <line x1="0" y1="120" x2="500" y2="120" stroke="#F1F5F9" strokeWidth="1" />

                {/* Area Fill */}
                <path
                  d="M 30,110 L 95,75 L 165,95 L 235,85 L 305,50 L 375,68 L 450,85 L 450,150 L 30,150 Z"
                  fill="rgba(37, 99, 235, 0.08)"
                />

                {/* Line */}
                <polyline
                  fill="none"
                  stroke="#2563EB"
                  strokeWidth="2.5"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  points="30,110 95,75 165,95 235,85 305,50 375,68 450,85"
                />

                {/* Points */}
                {[
                  { cx: 30, cy: 110, val: 8 },
                  { cx: 95, cy: 75, val: 12 },
                  { cx: 165, cy: 95, val: 10 },
                  { cx: 235, cy: 85, val: 11 },
                  { cx: 305, cy: 50, val: 15 },
                  { cx: 375, cy: 68, val: 13 },
                  { cx: 450, cy: 85, val: pendingCount },
                ].map((pt, i) => (
                  <g key={i}>
                    <circle cx={pt.cx} cy={pt.cy} r="4.5" fill="#FFFFFF" stroke="#2563EB" strokeWidth="2.5" />
                    <text
                      x={pt.cx}
                      y={pt.cy - 10}
                      textAnchor="middle"
                      fill="#64748B"
                      fontSize="10"
                      fontFamily="JetBrains Mono"
                    >
                      {pt.val}
                    </text>
                  </g>
                ))}
              </svg>
            </div>

            {/* Day labels */}
            <div className="flex justify-between text-[11px] font-mono text-slate-500 pt-2 border-t border-slate-100">
              {trendPoints.map((tp, idx) => (
                <span key={idx}>{tp.day}</span>
              ))}
            </div>
          </div>
        </div>

        {/* Right Column (Most Reported Locations + Facility Status) - 5 cols */}
        <div className="lg:col-span-5 space-y-5">
          {/* Most Reported Locations */}
          <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-xs">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-sm font-bold text-slate-900">Most Reported Locations</h3>
              <button
                onClick={onNavigateToMap}
                className="text-xs font-semibold text-blue-600 hover:text-blue-800 flex items-center gap-1"
              >
                <span>View on Map</span>
                <ChevronRight className="w-3.5 h-3.5" />
              </button>
            </div>

            <div className="space-y-3">
              {[
                { name: 'Block A Lift', count: 3, percentage: 75, severity: 'rose' },
                { name: 'Main Gate Pathway', count: 2, percentage: 50, severity: 'amber' },
                { name: 'Library Ramp', count: 2, percentage: 50, severity: 'amber' },
                { name: 'Auditorium Toilet', count: 1, percentage: 25, severity: 'blue' },
                { name: 'Other Areas', count: 4, percentage: 65, severity: 'slate' },
              ].map((loc, i) => (
                <div key={i} className="group">
                  <div className="flex items-center justify-between text-xs mb-1">
                    <span className="font-medium text-slate-800 flex items-center gap-1.5">
                      <Building2 className="w-3.5 h-3.5 text-slate-400" />
                      {loc.name}
                    </span>
                    <span className="font-mono tabular-nums font-semibold text-slate-700">
                      {loc.count} {loc.count === 1 ? 'issue' : 'issues'}
                    </span>
                  </div>
                  <div className="h-1.5 w-full bg-slate-100 rounded-full overflow-hidden">
                    <div
                      className={`h-full rounded-full transition-all duration-500 ${
                        loc.severity === 'rose'
                          ? 'bg-rose-500'
                          : loc.severity === 'amber'
                          ? 'bg-amber-500'
                          : loc.severity === 'blue'
                          ? 'bg-blue-500'
                          : 'bg-slate-400'
                      }`}
                      style={{ width: `${loc.percentage}%` }}
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Facility Status Summary (Matching photo) */}
          <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-xs">
            <h3 className="text-sm font-bold text-slate-900 mb-3">Facility Status Overview</h3>
            <div className="grid grid-cols-3 gap-3 text-center">
              <div className="p-3 bg-slate-50 rounded-lg border border-slate-200/60">
                <div className="w-7 h-7 mx-auto rounded-md bg-blue-100 text-blue-700 flex items-center justify-center mb-1.5">
                  <ArrowUpDown className="w-4 h-4" />
                </div>
                <div className="text-xs font-semibold text-slate-800">Lifts</div>
                <div className="text-xs font-mono font-bold text-emerald-600 mt-0.5">
                  {lifts.operational}/{lifts.total} Working
                </div>
              </div>

              <div className="p-3 bg-slate-50 rounded-lg border border-slate-200/60">
                <div className="w-7 h-7 mx-auto rounded-md bg-purple-100 text-purple-700 flex items-center justify-center mb-1.5">
                  <TrendingUp className="w-4 h-4" />
                </div>
                <div className="text-xs font-semibold text-slate-800">Ramps</div>
                <div className="text-xs font-mono font-bold text-purple-700 mt-0.5">
                  {ramps.operational}/{ramps.total} Accessible
                </div>
              </div>

              <div className="p-3 bg-slate-50 rounded-lg border border-slate-200/60">
                <div className="w-7 h-7 mx-auto rounded-md bg-emerald-100 text-emerald-700 flex items-center justify-center mb-1.5">
                  <DoorOpen className="w-4 h-4" />
                </div>
                <div className="text-xs font-semibold text-slate-800">Toilets</div>
                <div className="text-xs font-mono font-bold text-emerald-600 mt-0.5">
                  {toilets.operational}/{toilets.total} Accessible
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Row 3: Live Reported Issues Management Table */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="p-5 border-b border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h3 className="text-sm font-bold text-slate-900">Live Reported Campus Incidents</h3>
            <p className="text-xs text-slate-500">
              Track, dispatch, and mark resolved campus accessibility obstacles
            </p>
          </div>

          <div className="flex items-center gap-2">
            {/* Filter buttons */}
            <div className="flex items-center bg-slate-100 p-1 rounded-lg text-xs">
              {['all', 'lift', 'ramp', 'path', 'toilet'].map((t) => (
                <button
                  key={t}
                  onClick={() => setFilterType(t)}
                  className={`px-2.5 py-1 rounded-md capitalize font-medium transition-colors ${
                    filterType === t
                      ? 'bg-white text-slate-900 shadow-xs font-semibold'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  {t}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Table Content */}
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50/80 border-b border-slate-200 text-slate-500 font-semibold uppercase tracking-wider text-[11px]">
              <tr>
                <th className="py-3 px-4">Ticket</th>
                <th className="py-3 px-4">Problem Description</th>
                <th className="py-3 px-4">Location</th>
                <th className="py-3 px-4">Severity</th>
                <th className="py-3 px-4">Reported</th>
                <th className="py-3 px-4">Status</th>
                <th className="py-3 px-4 text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredIssues.map((issue) => (
                <tr key={issue.id} className="hover:bg-slate-50/60 transition-colors">
                  <td className="py-3 px-4 font-mono font-medium text-slate-500">
                    {issue.id}
                  </td>
                  <td className="py-3 px-4">
                    <div className="font-semibold text-slate-900">{issue.title}</div>
                    {issue.description && (
                      <div className="text-[11px] text-slate-500 line-clamp-1">
                        {issue.description}
                      </div>
                    )}
                  </td>
                  <td className="py-3 px-4 text-slate-700 font-medium">
                    {issue.location}
                  </td>
                  <td className="py-3 px-4">
                    <span
                      className={`inline-flex items-center px-2 py-0.5 rounded text-[11px] font-semibold ${
                        issue.severity === 'high'
                          ? 'bg-rose-50 text-rose-700 border border-rose-200'
                          : issue.severity === 'medium'
                          ? 'bg-amber-50 text-amber-700 border border-amber-200'
                          : 'bg-slate-100 text-slate-700'
                      }`}
                    >
                      {issue.severity.toUpperCase()}
                    </span>
                  </td>
                  <td className="py-3 px-4 text-slate-500 font-mono text-[11px]">
                    {issue.reportedAt}
                  </td>
                  <td className="py-3 px-4">
                    <span
                      className={`inline-flex items-center gap-1 text-xs font-medium ${
                        issue.status === 'resolved'
                          ? 'text-emerald-600'
                          : issue.status === 'in_review'
                          ? 'text-blue-600'
                          : 'text-amber-600'
                      }`}
                    >
                      <span
                        className={`w-1.5 h-1.5 rounded-full ${
                          issue.status === 'resolved'
                            ? 'bg-emerald-500'
                            : issue.status === 'in_review'
                            ? 'bg-blue-500'
                            : 'bg-amber-500'
                        }`}
                      />
                      {issue.status === 'resolved'
                        ? 'Resolved'
                        : issue.status === 'in_review'
                        ? 'In Review'
                        : 'Pending'}
                    </span>
                  </td>
                  <td className="py-3 px-4 text-right">
                    {issue.status !== 'resolved' ? (
                      <button
                        onClick={() => onResolveIssue(issue.id)}
                        className="inline-flex items-center gap-1 px-2.5 py-1 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 rounded-md font-semibold transition-colors cursor-pointer"
                        title="Mark obstacle as resolved"
                      >
                        <Check className="w-3.5 h-3.5" />
                        <span>Resolve</span>
                      </button>
                    ) : (
                      <span className="text-[11px] text-slate-400 italic">Completed</span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
