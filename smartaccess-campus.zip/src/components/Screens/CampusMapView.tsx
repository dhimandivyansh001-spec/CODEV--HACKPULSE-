import React, { useState } from 'react';
import {
  Compass,
  Search,
  MapPin,
  Layers,
  Info,
  Navigation as NavIcon,
  Maximize2,
  Minimize2,
  CheckCircle,
  AlertTriangle,
  ArrowUpDown,
  TrendingUp,
  DoorOpen,
  Building2,
  X,
} from 'lucide-react';
import { CAMPUS_BUILDINGS } from '../../data/mockCampusData';
import { CampusBuilding, DesignTokenCustomizer } from '../../types/tokens';

interface CampusMapViewProps {
  onPlanRouteTo: (destination: string) => void;
  tokenConfig: DesignTokenCustomizer;
}

export const CampusMapView: React.FC<CampusMapViewProps> = ({
  onPlanRouteTo,
  tokenConfig,
}) => {
  const [selectedBuilding, setSelectedBuilding] = useState<CampusBuilding | null>(
    CAMPUS_BUILDINGS.find((b) => b.id === 'bld-comp-lab') || null
  );
  const [activeLayer, setActiveLayer] = useState<'all' | 'ramps' | 'lifts' | 'toilets'>('all');
  const [searchMap, setSearchMap] = useState('');

  // Markers on map
  const markers = [
    { id: 'm-gate', type: 'location', label: 'Main Gate (You are here)', x: 50, y: 76, color: '#EF4444' },
    { id: 'm-ramp-a', type: 'ramp', label: 'Courtyard Ramp A (1:12 ADA)', x: 38, y: 55, color: '#8B5CF6' },
    { id: 'm-lift-a', type: 'lift', label: 'Building A / Block B Lift', x: 26, y: 38, color: '#2563EB' },
    { id: 'm-toilet-b', type: 'toilet', label: 'Accessible Restroom B-102', x: 28, y: 46, color: '#059669' },
    { id: 'm-ramp-lib', type: 'ramp', label: 'Library Access Ramp', x: 44, y: 28, color: '#8B5CF6' },
    { id: 'm-lift-lib', type: 'lift', label: 'Library Main Lift (Nominal)', x: 56, y: 16, color: '#2563EB' },
    { id: 'm-audit-ramp', type: 'ramp', label: 'Auditorium Slope Ramp', x: 74, y: 44, color: '#8B5CF6' },
    { id: 'm-dest', type: 'destination', label: 'Computer Lab (Destination)', x: 24, y: 34, color: '#DC2626' },
  ];

  const filteredMarkers = markers.filter((m) => {
    if (activeLayer === 'ramps') return m.type === 'ramp';
    if (activeLayer === 'lifts') return m.type === 'lift';
    if (activeLayer === 'toilets') return m.type === 'toilet';
    return true;
  });

  return (
    <div className="space-y-4">
      {/* Map Header & Controls */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h2 className="text-xl font-bold text-slate-900 tracking-tight flex items-center gap-2">
            <Compass className="w-5 h-5 text-blue-600" />
            <span>Interactive Campus Map</span>
          </h2>
          <p className="text-xs text-slate-500">
            Real-time accessibility wayfinding & facility topology
          </p>
        </div>

        {/* Filter Layers */}
        <div className="flex items-center gap-1.5 bg-slate-100 p-1 rounded-xl text-xs overflow-x-auto">
          {[
            { id: 'all', label: 'All Layers' },
            { id: 'ramps', label: 'Ramps' },
            { id: 'lifts', label: 'Lifts' },
            { id: 'toilets', label: 'Accessible Toilets' },
          ].map((l) => (
            <button
              key={l.id}
              onClick={() => setActiveLayer(l.id as any)}
              className={`px-3 py-1.5 rounded-lg font-medium transition-all whitespace-nowrap cursor-pointer ${
                activeLayer === l.id
                  ? 'bg-white text-slate-900 shadow-xs font-semibold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              {l.label}
            </button>
          ))}
        </div>
      </div>

      {/* Main Map Viewport & Sidebar Split */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* Map Canvas (8 cols on lg) */}
        <div className="lg:col-span-8 bg-slate-50 rounded-2xl border border-slate-200 overflow-hidden relative shadow-xs min-h-[460px] flex flex-col justify-between p-4">
          {/* Top Search Overlay */}
          <div className="relative z-10 max-w-md w-full">
            <div className="relative">
              <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
              <input
                type="text"
                placeholder="Search building, room or facility..."
                value={searchMap}
                onChange={(e) => setSearchMap(e.target.value)}
                className="w-full pl-10 pr-10 py-2.5 bg-white/95 backdrop-blur-md rounded-xl border border-slate-200 shadow-sm text-xs text-slate-800 placeholder-slate-400 focus:outline-hidden focus:ring-2 focus:ring-blue-500"
              />
              <button
                className="absolute right-3 top-2.5 p-1 rounded-md text-slate-400 hover:text-blue-600 transition-colors"
                title="Locate me"
              >
                <NavIcon className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          {/* SVG Vector Blueprint Map */}
          <div className="absolute inset-0 z-0 flex items-center justify-center p-4">
            <svg
              className="w-full h-full max-h-[500px]"
              viewBox="0 0 800 520"
              xmlns="http://www.w3.org/2000/svg"
            >
              {/* Campus Grounds / Lawn Base */}
              <rect x="0" y="0" width="800" height="520" fill="#F1F5F9" />
              <circle cx="400" cy="180" r="140" fill="#DCFCE7" opacity="0.6" />
              <circle cx="200" cy="320" r="90" fill="#DCFCE7" opacity="0.4" />
              <circle cx="650" cy="320" r="80" fill="#DCFCE7" opacity="0.5" />

              {/* Pathways & Roads */}
              {/* Main Plaza Path */}
              <path
                d="M 400 480 L 400 240 M 400 360 L 220 320 M 400 280 L 580 280 M 220 320 L 220 220 L 320 180"
                stroke="#E2E8F0"
                strokeWidth="24"
                strokeLinecap="round"
                strokeLinejoin="round"
                fill="none"
              />
              {/* Accessible Tactile Route (Dashed Blue) */}
              <path
                d="M 400 440 L 400 350 L 260 320 L 220 250 L 220 200"
                stroke="#3B82F6"
                strokeWidth="4"
                strokeDasharray="6 4"
                strokeLinecap="round"
                fill="none"
              />

              {/* Building Blocks */}
              {/* Library */}
              <g
                className="cursor-pointer transition-transform hover:opacity-90"
                onClick={() =>
                  setSelectedBuilding(
                    CAMPUS_BUILDINGS.find((b) => b.id === 'bld-library') || null
                  )
                }
              >
                <rect
                  x="300"
                  y="70"
                  width="200"
                  height="110"
                  rx="12"
                  fill="#FFFFFF"
                  stroke="#93C5FD"
                  strokeWidth="2"
                  filter="drop-shadow(0px 4px 6px rgba(0,0,0,0.05))"
                />
                <rect x="310" y="80" width="180" height="30" rx="6" fill="#DBEAFE" />
                <text x="400" y="100" textAnchor="middle" fill="#1E40AF" fontWeight="bold" fontSize="13">
                  Central Library
                </text>
                <text x="400" y="145" textAnchor="middle" fill="#64748B" fontSize="11">
                  4 Floors · 2 Lifts · 2 Ramps
                </text>
              </g>

              {/* Academic Block B */}
              <g
                className="cursor-pointer transition-transform hover:opacity-90"
                onClick={() =>
                  setSelectedBuilding(
                    CAMPUS_BUILDINGS.find((b) => b.id === 'bld-block-b') || null
                  )
                }
              >
                <rect
                  x="120"
                  y="200"
                  width="170"
                  height="130"
                  rx="12"
                  fill="#FFFFFF"
                  stroke="#A7F3D0"
                  strokeWidth="2"
                  filter="drop-shadow(0px 4px 6px rgba(0,0,0,0.05))"
                />
                <rect x="130" y="210" width="150" height="26" rx="6" fill="#D1FAE5" />
                <text x="205" y="228" textAnchor="middle" fill="#065F46" fontWeight="bold" fontSize="13">
                  Academic Block B
                </text>
                <text x="205" y="265" textAnchor="middle" fill="#64748B" fontSize="11">
                  Computer Lab (2nd Fl)
                </text>
                <text x="205" y="295" textAnchor="middle" fill="#059669" fontWeight="500" fontSize="10">
                  ✓ Ramp A & Lift A Active
                </text>
              </g>

              {/* Grand Auditorium */}
              <g
                className="cursor-pointer transition-transform hover:opacity-90"
                onClick={() =>
                  setSelectedBuilding(
                    CAMPUS_BUILDINGS.find((b) => b.id === 'bld-auditorium') || null
                  )
                }
              >
                <rect
                  x="510"
                  y="210"
                  width="170"
                  height="120"
                  rx="12"
                  fill="#FFFFFF"
                  stroke="#E9D5FF"
                  strokeWidth="2"
                  filter="drop-shadow(0px 4px 6px rgba(0,0,0,0.05))"
                />
                <rect x="520" y="220" width="150" height="26" rx="6" fill="#F3E8FF" />
                <text x="595" y="238" textAnchor="middle" fill="#6B21A8" fontWeight="bold" fontSize="13">
                  Auditorium
                </text>
                <text x="595" y="275" textAnchor="middle" fill="#64748B" fontSize="11">
                  Slope Ramp & Assist Audio
                </text>
              </g>

              {/* Main Gate */}
              <g
                className="cursor-pointer"
                onClick={() =>
                  setSelectedBuilding(
                    CAMPUS_BUILDINGS.find((b) => b.id === 'bld-main-gate') || null
                  )
                }
              >
                <rect
                  x="330"
                  y="410"
                  width="140"
                  height="65"
                  rx="10"
                  fill="#FFFFFF"
                  stroke="#CBD5E1"
                  strokeWidth="2"
                />
                <text x="400" y="440" textAnchor="middle" fill="#0F172A" fontWeight="bold" fontSize="12">
                  Main Gate
                </text>
                <text x="400" y="460" textAnchor="middle" fill="#64748B" fontSize="10">
                  Welcome Center
                </text>
              </g>

              {/* Interactive Vector Pins */}
              {filteredMarkers.map((marker) => {
                const px = (marker.x * 800) / 100;
                const py = (marker.y * 520) / 100;
                return (
                  <g key={marker.id} className="transition-all hover:scale-125 cursor-pointer">
                    <circle cx={px} cy={py} r="14" fill={marker.color} opacity="0.2" />
                    <circle cx={px} cy={py} r="8" fill={marker.color} stroke="#FFFFFF" strokeWidth="2" />
                  </g>
                );
              })}
            </svg>
          </div>

          {/* Bottom Floating Bar (Matching photo: "Current Location: Main Gate") */}
          <div className="relative z-10 bg-white/95 backdrop-blur-md rounded-xl p-3 border border-slate-200/90 shadow-md flex items-center justify-between max-w-md">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-lg bg-rose-100 text-rose-600 flex items-center justify-center font-bold">
                <MapPin className="w-4 h-4" />
              </div>
              <div>
                <span className="text-[10px] uppercase font-bold text-slate-400 block">
                  Current Location
                </span>
                <span className="text-xs font-bold text-slate-900">Main Gate (North Plaza)</span>
              </div>
            </div>

            <button
              onClick={() => onPlanRouteTo('Computer Lab (Block B)')}
              className="px-3 py-1.5 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
            >
              <NavIcon className="w-3 h-3" />
              <span>Route from here</span>
            </button>
          </div>
        </div>

        {/* Right Sidebar: Campus Legend & Selected Facility Details (4 cols) */}
        <div className="lg:col-span-4 space-y-4">
          {/* Selected Building Details Drawer */}
          {selectedBuilding ? (
            <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
              <div className="flex items-start justify-between">
                <div>
                  <span className="text-[10px] font-bold uppercase tracking-wider text-blue-600">
                    {selectedBuilding.code}
                  </span>
                  <h3 className="text-base font-bold text-slate-900 mt-0.5">
                    {selectedBuilding.name}
                  </h3>
                </div>
                <button
                  onClick={() => setSelectedBuilding(null)}
                  className="p-1 rounded-md text-slate-400 hover:text-slate-600"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <div className="mt-4 space-y-2.5 text-xs">
                <div className="flex items-center justify-between p-2 rounded-lg bg-slate-50">
                  <span className="text-slate-600 flex items-center gap-2">
                    <TrendingUp className="w-4 h-4 text-purple-600" />
                    Wheelchair Ramps
                  </span>
                  <span className="font-semibold text-slate-900 font-mono">
                    {selectedBuilding.ramps} available
                  </span>
                </div>

                <div className="flex items-center justify-between p-2 rounded-lg bg-slate-50">
                  <span className="text-slate-600 flex items-center gap-2">
                    <ArrowUpDown className="w-4 h-4 text-blue-600" />
                    Operational Elevators
                  </span>
                  <span className="font-semibold text-slate-900 font-mono">
                    {selectedBuilding.lifts} active
                  </span>
                </div>

                <div className="flex items-center justify-between p-2 rounded-lg bg-slate-50">
                  <span className="text-slate-600 flex items-center gap-2">
                    <DoorOpen className="w-4 h-4 text-emerald-600" />
                    Accessible Restrooms
                  </span>
                  <span className="font-semibold text-slate-900 font-mono">
                    {selectedBuilding.accessibleToilets} on ground floor
                  </span>
                </div>
              </div>

              <div className="mt-5 pt-4 border-t border-slate-100">
                <button
                  onClick={() => onPlanRouteTo(selectedBuilding.name)}
                  className="w-full py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-semibold transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <span>Plan Accessible Route to this building</span>
                  <NavIcon className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          ) : (
            <div className="bg-white p-5 rounded-2xl border border-slate-200 text-center text-xs text-slate-500">
              <Building2 className="w-8 h-8 mx-auto text-slate-300 mb-2" />
              Click any campus building to inspect accessibility clearance and elevator status
            </div>
          )}

          {/* Map Legend (Directly matching photo) */}
          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
            <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider mb-3">
              Map Legend & Symbols
            </h4>
            <div className="grid grid-cols-2 gap-2.5 text-xs text-slate-700">
              <div className="flex items-center gap-2">
                <div className="w-4 h-4 rounded-sm bg-blue-100 border border-blue-300" />
                <span>Building</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-3.5 h-3.5 rounded-full bg-purple-600" />
                <span>Ramp (ADA)</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-3.5 h-3.5 rounded-full bg-blue-600" />
                <span>Lift / Elevator</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-3.5 h-3.5 rounded-full bg-emerald-600" />
                <span>Accessible Toilet</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-3.5 h-3.5 rounded-full bg-amber-500" />
                <span>Entrance</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-3.5 h-3.5 rounded-full bg-rose-600" />
                <span>Your Location</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-3.5 h-3.5 rounded-full bg-red-600" />
                <span>Destination</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
