import React, { useState } from 'react';
import {
  AlertTriangle,
  ArrowUpDown,
  TrendingUp,
  Cone,
  DoorOpen,
  Camera,
  CheckCircle2,
  UploadCloud,
  ChevronDown,
  ArrowRight,
} from 'lucide-react';
import { CampusIssue, DesignTokenCustomizer } from '../../types/tokens';

interface ReportIssueViewProps {
  onAddIssue: (newIssue: Omit<CampusIssue, 'id' | 'reportedAt' | 'status'>) => void;
  onNavigateToDashboard: () => void;
  tokenConfig: DesignTokenCustomizer;
}

export const ReportIssueView: React.FC<ReportIssueViewProps> = ({
  onAddIssue,
  onNavigateToDashboard,
  tokenConfig,
}) => {
  const [selectedType, setSelectedType] = useState<CampusIssue['type']>('lift');
  const [location, setLocation] = useState('Building A - Lift 2');
  const [description, setDescription] = useState('');
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [hasPhoto, setHasPhoto] = useState(false);

  const problemOptions = [
    {
      id: 'lift',
      title: 'Lift not working',
      icon: <ArrowUpDown className="w-4 h-4 text-blue-600" />,
      desc: 'Power failure, out of service, or buttons unresponsive',
    },
    {
      id: 'ramp',
      title: 'Ramp blocked',
      icon: <TrendingUp className="w-4 h-4 text-purple-600" />,
      desc: 'Obstacles, construction gear, or locked access gate',
    },
    {
      id: 'path',
      title: 'Path blocked',
      icon: <Cone className="w-4 h-4 text-amber-600" />,
      desc: 'Potholes, broken paving, debris, or wet floor without warning',
    },
    {
      id: 'toilet',
      title: 'Accessible toilet unavailable',
      icon: <DoorOpen className="w-4 h-4 text-emerald-600" />,
      desc: 'Locked door, broken emergency pull cord, or grab bar issue',
    },
    {
      id: 'other',
      title: 'Other accessibility issue',
      icon: <AlertTriangle className="w-4 h-4 text-slate-600" />,
      desc: 'Signage missing, tactile paving broken, or heavy door',
    },
  ];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const problem = problemOptions.find((p) => p.id === selectedType);
    onAddIssue({
      type: selectedType,
      title: problem?.title || 'Reported Issue',
      location: location,
      building: location.split(' - ')[0] || 'Campus Zone',
      severity: selectedType === 'lift' || selectedType === 'ramp' ? 'high' : 'medium',
      description: description || 'Issue submitted by campus community member via app.',
    });
    setIsSubmitted(true);
  };

  return (
    <div className="max-w-2xl mx-auto space-y-6">
      {/* Title */}
      <div className="pb-3 border-b border-slate-200">
        <h2 className="text-xl font-bold text-slate-900 tracking-tight">
          Report an Issue
        </h2>
        <p className="text-xs text-slate-500">
          Help us keep the campus accessible for everyone. Reports immediately notify facility maintenance.
        </p>
      </div>

      {isSubmitted ? (
        <div className="bg-white p-8 rounded-2xl border border-slate-200 shadow-xs text-center space-y-4">
          <div className="w-14 h-14 mx-auto rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center">
            <CheckCircle2 className="w-8 h-8" />
          </div>
          <div>
            <h3 className="text-lg font-bold text-slate-900">
              Report Submitted Successfully!
            </h3>
            <p className="text-xs text-slate-500 max-w-md mx-auto mt-1">
              Thank you for keeping our campus barrier-free. Campus Facilities Dispatch has received ticket for <strong>{location}</strong>.
            </p>
          </div>
          <div className="pt-2 flex justify-center gap-3">
            <button
              onClick={() => setIsSubmitted(false)}
              className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-semibold transition-colors"
            >
              Report Another Issue
            </button>
            <button
              onClick={onNavigateToDashboard}
              className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-semibold transition-colors flex items-center gap-1.5"
            >
              <span>View in Admin Console</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      ) : (
        <form onSubmit={handleSubmit} className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs space-y-5">
          {/* Question: What is the problem? */}
          <div>
            <label className="text-xs font-bold text-slate-900 block mb-2">
              What is the problem?
            </label>
            <div className="space-y-2">
              {problemOptions.map((opt) => (
                <label
                  key={opt.id}
                  onClick={() => setSelectedType(opt.id as any)}
                  className={`flex items-center justify-between p-3.5 rounded-xl border transition-all cursor-pointer ${
                    selectedType === opt.id
                      ? 'border-blue-600 bg-blue-50/50 shadow-xs ring-1 ring-blue-600'
                      : 'border-slate-200 hover:bg-slate-50'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <div className="p-2 rounded-lg bg-white border border-slate-200 shadow-xs">
                      {opt.icon}
                    </div>
                    <div>
                      <span className="text-xs font-bold text-slate-900 block">
                        {opt.title}
                      </span>
                      <span className="text-[11px] text-slate-500">
                        {opt.desc}
                      </span>
                    </div>
                  </div>
                  <div className="w-5 h-5 rounded-full border-2 flex items-center justify-center transition-colors">
                    {selectedType === opt.id ? (
                      <div className="w-2.5 h-2.5 rounded-full bg-blue-600" />
                    ) : (
                      <div className="w-2.5 h-2.5 rounded-full border border-slate-300" />
                    )}
                  </div>
                </label>
              ))}
            </div>
          </div>

          {/* Location Dropdown */}
          <div>
            <label className="text-xs font-bold text-slate-900 block mb-1.5">
              Location
            </label>
            <div className="relative">
              <select
                value={location}
                onChange={(e) => setLocation(e.target.value)}
                className="w-full appearance-none py-2.5 pl-3.5 pr-10 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-800 focus:outline-hidden focus:ring-2 focus:ring-blue-500 focus:bg-white"
              >
                <option value="Building A - Lift 2">Building A - Lift 2</option>
                <option value="Library Main Entrance Ramp">Library Main Entrance Ramp</option>
                <option value="Main Gate Pathway (North Walk)">Main Gate Pathway (North Walk)</option>
                <option value="Auditorium Ground Floor Toilet 1B">Auditorium Ground Floor Toilet 1B</option>
                <option value="Block B Central Lift">Block B Central Lift</option>
                <option value="Computer Lab Corridor (2nd Floor)">Computer Lab Corridor (2nd Floor)</option>
              </select>
              <ChevronDown className="w-4 h-4 text-slate-400 absolute right-3 top-3 pointer-events-none" />
            </div>
          </div>

          {/* Additional details */}
          <div>
            <label className="text-xs font-bold text-slate-900 block mb-1.5">
              Additional Details (Optional)
            </label>
            <textarea
              rows={2}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="e.g. Elevator door gets stuck on 2nd floor, warning beep sounds..."
              className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-800 placeholder-slate-400 focus:outline-hidden focus:ring-2 focus:ring-blue-500 focus:bg-white"
            />
          </div>

          {/* Add Photo Attachment Zone (Matching photo) */}
          <div>
            <label className="text-xs font-bold text-slate-900 block mb-1.5">
              Add Photo (Optional)
            </label>
            <div
              onClick={() => setHasPhoto(!hasPhoto)}
              className={`border-2 border-dashed rounded-xl p-5 text-center cursor-pointer transition-colors ${
                hasPhoto
                  ? 'border-emerald-400 bg-emerald-50/50'
                  : 'border-slate-200 hover:border-slate-300 bg-slate-50/50'
              }`}
            >
              {hasPhoto ? (
                <div className="flex items-center justify-center gap-2 text-xs font-semibold text-emerald-700">
                  <CheckCircle2 className="w-5 h-5 text-emerald-600" />
                  <span>Photo attached (obstacle_photo_01.jpg) · Tap to remove</span>
                </div>
              ) : (
                <div className="space-y-1">
                  <Camera className="w-6 h-6 mx-auto text-slate-400" />
                  <div className="text-xs font-semibold text-slate-700">
                    Tap to upload or take a photo
                  </div>
                  <div className="text-[11px] text-slate-400">
                    PNG, JPG, HEIC up to 10MB
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Submit Button */}
          <button
            type="submit"
            className="w-full py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-xl font-bold text-xs flex items-center justify-center gap-2 shadow-xs transition-all cursor-pointer"
          >
            <span>Submit Report</span>
            <span>🚀</span>
          </button>
        </form>
      )}
    </div>
  );
};
