import React, { useState } from 'react';
import {
  Sparkles,
  Copy,
  Check,
  Download,
  LayoutDashboard,
  Compass,
  MapPin,
  AlertTriangle,
  MessageSquare,
  Smartphone,
  Palette,
  ExternalLink,
  Code2,
} from 'lucide-react';
import { Navigation, ActiveScreen } from './components/Navigation';
import { PromptModal } from './components/PromptStudio/PromptModal';
import { AdminDashboardView } from './components/Screens/AdminDashboardView';
import { CampusMapView } from './components/Screens/CampusMapView';
import { RoutePlannerView } from './components/Screens/RoutePlannerView';
import { ReportIssueView } from './components/Screens/ReportIssueView';
import { AiAssistantView } from './components/Screens/AiAssistantView';
import { MobileHomeView } from './components/Screens/MobileHomeView';
import { DesignTokensView } from './components/Screens/DesignTokensView';
import { INITIAL_ISSUES, INITIAL_FACILITIES } from './data/mockCampusData';
import { CampusIssue, DesignTokenCustomizer } from './types/tokens';
import { FIGMA_AI_MASTER_PROMPT } from './data/figmaPrompts';

export default function App() {
  const [activeScreen, setActiveScreen] = useState<ActiveScreen>('dashboard');
  const [issues, setIssues] = useState<CampusIssue[]>(INITIAL_ISSUES);
  const [facilities, setFacilities] = useState(INITIAL_FACILITIES);
  const [isPromptModalOpen, setIsPromptModalOpen] = useState(false);
  const [quickCopied, setQuickCopied] = useState(false);
  const [targetDestination, setTargetDestination] = useState<string>('Computer Lab (Block B)');
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const [tokenConfig, setTokenConfig] = useState<DesignTokenCustomizer>({
    primaryColor: '#2563EB',
    primaryName: 'Campus Blue',
    accentMode: 'blue',
    borderRadius: 'rounded-xl',
    radiusPx: 10,
    fontScale: 'standard',
    themeMode: 'light',
  });

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3000);
  };

  const handleResolveIssue = (id: string) => {
    setIssues((prev) =>
      prev.map((iss) => (iss.id === id ? { ...iss, status: 'resolved' } : iss))
    );
    showToast('Issue marked as resolved and campus accessibility score updated!');
  };

  const handleAddIssue = (
    newIssueData: Omit<CampusIssue, 'id' | 'reportedAt' | 'status'>
  ) => {
    const newIssue: CampusIssue = {
      ...newIssueData,
      id: `ISS-${Math.floor(100 + Math.random() * 900)}`,
      reportedAt: 'Just now',
      status: 'pending',
    };
    setIssues((prev) => [newIssue, ...prev]);
    showToast(`Issue ${newIssue.id} logged and dispatched to facilities dashboard.`);
  };

  const handlePlanRouteTo = (destination: string) => {
    setTargetDestination(destination);
    setActiveScreen('route');
  };

  const handleQuickCopyPrompt = () => {
    navigator.clipboard.writeText(FIGMA_AI_MASTER_PROMPT);
    setQuickCopied(true);
    showToast('Figma Master Prompt copied to clipboard!');
    setTimeout(() => setQuickCopied(false), 2000);
  };

  const pendingIssueCount = issues.filter((i) => i.status !== 'resolved').length;

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 font-sans flex flex-col selection:bg-blue-100 selection:text-blue-900">
      {/* Top Bar adhering to Top Bar Contract */}
      <Navigation
        activeScreen={activeScreen}
        onSelectScreen={setActiveScreen}
        onOpenPromptModal={() => setIsPromptModalOpen(true)}
        issueCount={pendingIssueCount}
      />

      {/* Global Quick Action & Prompt Bar */}
      <section className="bg-slate-900 text-white border-b border-slate-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-2.5 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-2 text-slate-300">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            <span className="font-semibold text-white">SmartAccess Campus:</span>
            <span className="hidden md:inline">
              Figma Design System with 6 high-fidelity screens, editable components, and structured W3C tokens.
            </span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleQuickCopyPrompt}
              className="flex items-center gap-1.5 px-3 py-1 bg-blue-600 hover:bg-blue-500 text-white rounded-md font-semibold transition-colors cursor-pointer shadow-xs"
            >
              {quickCopied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{quickCopied ? 'Copied Prompt!' : '1-Click Copy Figma Prompt'}</span>
            </button>
            <button
              onClick={() => setIsPromptModalOpen(true)}
              className="flex items-center gap-1 px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-md transition-colors cursor-pointer"
            >
              <Code2 className="w-3.5 h-3.5" />
              <span>Tokens & Variants</span>
            </button>
          </div>
        </div>
      </section>

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {activeScreen === 'dashboard' && (
          <AdminDashboardView
            issues={issues}
            facilities={facilities}
            onResolveIssue={handleResolveIssue}
            onNavigateToReport={() => setActiveScreen('report')}
            onNavigateToMap={() => setActiveScreen('map')}
            tokenConfig={tokenConfig}
          />
        )}

        {activeScreen === 'map' && (
          <CampusMapView
            onPlanRouteTo={handlePlanRouteTo}
            tokenConfig={tokenConfig}
          />
        )}

        {activeScreen === 'route' && (
          <RoutePlannerView
            initialDestination={targetDestination}
            onNavigateToMap={() => setActiveScreen('map')}
            tokenConfig={tokenConfig}
          />
        )}

        {activeScreen === 'report' && (
          <ReportIssueView
            onAddIssue={handleAddIssue}
            onNavigateToDashboard={() => setActiveScreen('dashboard')}
            tokenConfig={tokenConfig}
          />
        )}

        {activeScreen === 'ai' && (
          <AiAssistantView
            onNavigateToRoute={() => setActiveScreen('route')}
            tokenConfig={tokenConfig}
          />
        )}

        {activeScreen === 'mobile' && (
          <MobileHomeView
            onSelectScreen={setActiveScreen}
            tokenConfig={tokenConfig}
          />
        )}

        {activeScreen === 'tokens' && (
          <DesignTokensView
            tokenConfig={tokenConfig}
            onUpdateTokenConfig={(cfg) => setTokenConfig((prev) => ({ ...prev, ...cfg }))}
            onOpenPromptModal={() => setIsPromptModalOpen(true)}
          />
        )}
      </main>

      {/* Footer */}
      <footer className="bg-white border-t border-slate-200 py-6 text-xs text-slate-500">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <span className="font-bold text-slate-800">SmartAccess Campus</span>
            <span>·</span>
            <span>Inclusive Campus Navigation & SaaS Facilities Platform</span>
          </div>
          <div className="flex items-center gap-4">
            <button
              onClick={() => setIsPromptModalOpen(true)}
              className="text-blue-600 hover:text-blue-800 font-semibold cursor-pointer"
            >
              Figma Tokens & Spec
            </button>
            <span>·</span>
            <span>WCAG 2.1 AA Compliant</span>
          </div>
        </div>
      </footer>

      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-5 right-5 z-50 bg-slate-900 text-white px-4 py-3 rounded-xl shadow-xl border border-slate-800 flex items-center gap-2 text-xs font-medium animate-in fade-in slide-in-from-bottom-3 duration-200">
          <Check className="w-4 h-4 text-emerald-400" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Figma Prompt & Tokens Studio Modal */}
      <PromptModal
        isOpen={isPromptModalOpen}
        onClose={() => setIsPromptModalOpen(false)}
        tokenConfig={tokenConfig}
        onUpdateTokenConfig={(cfg) => setTokenConfig((prev) => ({ ...prev, ...cfg }))}
      />
    </div>
  );
}
