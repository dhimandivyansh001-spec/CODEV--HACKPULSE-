export type AccessibilityMode = 'wheelchair' | 'no-stairs' | 'visual' | 'normal';

export interface CampusIssue {
  id: string;
  type: 'lift' | 'ramp' | 'path' | 'toilet' | 'other';
  title: string;
  location: string;
  building: string;
  reportedAt: string;
  status: 'pending' | 'in_review' | 'resolved';
  severity: 'high' | 'medium' | 'low';
  imageUrl?: string;
  description?: string;
}

export interface FacilityStatus {
  id: string;
  name: string;
  total: number;
  operational: number;
  icon: string;
  statusPercent: number;
}

export interface RouteStep {
  stepNumber: number;
  instruction: string;
  location: string;
  facilityType: 'gate' | 'ramp' | 'building' | 'lift' | 'floor' | 'destination';
  accessible: boolean;
  distanceMeters: number;
}

export interface CampusBuilding {
  id: string;
  name: string;
  code: string;
  floors: number;
  lifts: number;
  ramps: number;
  accessibleToilets: number;
  status: 'fully_accessible' | 'partially_accessible' | 'maintenance';
  x: number; // percentage on map
  y: number;
  width: number;
  height: number;
}

export interface DesignTokenCustomizer {
  primaryColor: string; // hex
  primaryName: string;
  accentMode: 'blue' | 'indigo' | 'emerald' | 'amber';
  borderRadius: 'rounded-none' | 'rounded-md' | 'rounded-xl' | 'rounded-2xl' | 'rounded-3xl';
  radiusPx: number;
  fontScale: 'compact' | 'standard' | 'expanded';
  themeMode: 'light' | 'dark';
}
