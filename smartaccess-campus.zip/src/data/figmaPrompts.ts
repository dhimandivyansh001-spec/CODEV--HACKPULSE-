export const FIGMA_AI_MASTER_PROMPT = `Act as a world-class Principal Design Systems Engineer and Enterprise Product Designer. Generate a production-grade, highly polished, editable multi-screen design file in Figma for "SmartAccess Campus" — an inclusive campus navigation, accessibility routing, and SaaS facility management platform.

### DESIGN SYSTEM & DESIGN TOKENS (Create on Page "🎨 Foundations & Tokens"):
1. COLOR SYSTEM (Figma Local Variables, Light & Dark mode):
   - Brand Primary:
     * brand/primary-50: #EFF6FF
     * brand/primary-100: #DBEAFE
     * brand/primary-500: #3B82F6
     * brand/primary-600: #2563EB (Main interactive accent, WCAG AAA on white)
     * brand/primary-700: #1D4ED8
   - Accessibility Mode System:
     * mode/wheelchair: #2563EB (Accessible Blue)
     * mode/no-stairs: #8B5CF6 (Vibrant Violet / Purple)
     * mode/visual-assist: #059669 (High-Contrast Emerald Teal)
     * mode/standard: #475569 (Slate Neutral)
   - Semantic Statuses:
     * status/success: #10B981 (Working / 100% Accessible)
     * status/warning: #F59E0B (Partial / Minor Delay)
     * status/danger: #EF4444 (Broken / Blocked Route)
     * status/info: #0284C7 (Facility Information)
   - Neutrals & Surfaces:
     * surface/canvas: #F8FAFC
     * surface/card: #FFFFFF
     * surface/sidebar: #0F172A (or #FFFFFF for light mode)
     * border/subtle: #E2E8F0 (1px hairline)
     * text/primary: #0F172A
     * text/secondary: #64748B
     * text/muted: #94A3B8

2. TYPOGRAPHY (Figma Text Styles):
   - Font Family: "Plus Jakarta Sans" for UI, with "JetBrains Mono" / Tabular Figures for metrics.
   - Display/2XL: 32px / 40px, Bold (800)
   - Title/XL: 24px / 32px, SemiBold (700)
   - Heading/LG: 18px / 26px, SemiBold (600)
   - Body/MD: 14px / 20px, Regular (400) & Medium (500)
   - Caption/SM: 12px / 16px, Medium (500)
   - Mono/Data: 13px / 18px, font-variant-numeric: tabular-nums

3. SPACING & ELEVATIONS:
   - Spacing: 4px, 8px, 12px, 16px, 20px, 24px, 32px, 48px
   - Corner Radii: 6px (Input/Badge), 10px (Card), 16px (Panel), 9999px (Pill/Avatar)
   - Shadows: Soft elevation shadow (0px 1px 3px rgba(0, 0, 0, 0.05), 0px 4px 12px rgba(0, 0, 0, 0.04))

---

### COMPONENT SETS & EDITABLE VARIANTS (Page "🧩 Components"):
1. "Mode/Selector":
   - Properties: Mode = [Wheelchair | No-Stairs | Visual | Normal], State = [Default | Active | Hover]
   - Auto-Layout horizontal pill/card with SVG icon + 1-line label + active indicator.
2. "Card/Metric-KPI":
   - Properties: Status = [Reported-Issues | Active-Users | Working-Lifts | Accessible-Ramps], Trend = [Up | Down | Neutral]
   - Contains: Colored icon container, Large bold tabular stat (e.g. 12, 7/8), Title label, optional delta chip.
3. "Card/Route-Step":
   - Properties: Type = [Gate | Ramp | Building | Lift | Floor | Destination], Active = [True | False]
   - Vertical step timeline with auto-layout connector line, custom step icon, bold step title, distance in meters.
4. "Map/Marker-Pin":
   - Properties: Type = [UserLocation | Lift | Ramp | Toilet | Entrance | Destination], Selected = [True | False]
   - Vector pin badge with white icon and colored droplet container.
5. "Form/Issue-Option":
   - Radio selection card with icon, title, radio circle indicator, hover/selected ring.

---

### REQUIRED SCREENS (All in Strict Auto-Layout, 100% Vector & Editable):

Screen 1: "🖥️ Admin Dashboard (1440x960 desktop frame)"
- Left Sidebar (260px wide, dark slate #0F172A):
  * Brand wordmark "SmartAccess Campus" with wheelchair shield icon
  * Nav items: Overview (active indicator), Issues, Facilities, Reports, Settings, Support
  * User profile lockup at bottom with avatar and logout trigger
- Top Header: Breadcrumb "Admin Console / Live Campus Status", Date "Thursday, 3 Oct 2026", Search bar, Notification bell, Admin profile.
- Row 1 - 4x KPI Metric Cards:
  * Reported Issues: "12" (Danger icon, "3 high priority")
  * Active Users: "5" (Amber icon, "Campus visitors in transit")
  * Working Lifts: "7 / 8" (Emerald icon, "87.5% operational")
  * Accessible Ramps: "6 / 7" (Purple icon, "Ramp B undergoing cleaning")
- Row 2 - Two Column Split (70/30):
  * Left: Accessibility Score Card with Donut Chart (78%, "Overall campus accessibility is good. Keep improving!") + 7-Day Issues Trend Chart with Mon-Sun data points.
  * Right: "Most Reported Locations" list (Block A Lift: 3, Main Gate Pathway: 2, Library Ramp: 2, Auditorium Toilet: 1) with quick-assign buttons.
- Row 3 - Facility Status Grid:
  * Lifts: 7/8 Working (with toggle inspection drawer)
  * Ramps: 6/7 Accessible
  * Toilets: 4/5 Accessible

Screen 2: "🗺️ Campus Interactive Map (1440x900 desktop / 390x844 mobile toggle)"
- Navigation dock on left or floating top bar.
- Vector Campus Isometric/2.5D Blueprint featuring:
  * Library building, Academic Block B, Auditorium, Computer Lab, Main Gate.
  * Landscaped green courtyards, paved pedestrian walkways, tactile paving lines.
  * Dynamic vector markers: Lift pins, Ramp markers, Accessible Toilets, Entrance gates.
  * Legend modal: Building, Ramp, Lift, Accessible Toilet, Entrance, Your Location, Destination.
  * Bottom floating card: "Current Location: Main Gate" with quick "Start Navigation" button.

Screen 3: "📍 Route Planner Screen (390x844 mobile frame & 900px modal dialog)"
- Header: Back button, "Plan Your Route", Profile icon.
- Origin & Destination Inputs:
  * From: "Main Gate" with location pin & clear icon
  * To: "Computer Lab (Block B)" with destination pin
- Accessibility Preference Selector: 4 segmented tabs (Wheelchair, No Stairs, Visual Assistance, Normal).
- CTA: "Find Accessible Route ->" (Full width brand blue button).
- Route Result Sheet:
  * Meta pills: "Accessible Route", "~ 8 min", "350 m", "Zero stairs detected"
  * Step-by-Step Waypoints:
    1. Main Gate (Plaza Level)
    2. Courtyard Ramp A (1:12 slope)
    3. Building A North Entrance (Tactile door)
    4. Lift A (2nd Floor)
    5. Computer Lab (Block B - Room 204)

Screen 4: "⚠️ Report Issue Screen (390x844 mobile frame)"
- Header: "Report an Issue - Help us keep the campus accessible for everyone."
- Problem Type Radio List:
  * [x] Lift not working
  * [ ] Ramp blocked
  * [ ] Path blocked
  * [ ] Accessible toilet unavailable
  * [ ] Other
- Location Dropdown: Select "Building A - Lift 2".
- Media Upload: Dashed drag-and-drop zone with camera icon "Tap to upload or take a photo".
- Submit Button: Primary Blue button "Submit Report 🚀".

Screen 5: "🤖 Campus AI Assistant Screen (390x844 mobile & 800px chat panel)"
- Header: "Campus AI Assistant - Ask anything about campus facilities, routes or accessibility."
- Conversational chat thread:
  * User Bubble: "How can I reach the library without stairs?"
  * Assistant Response Bubble: "You can reach the library using the accessible route: 1. Start from Main Gate 2. Use Ramp A 3. Take Lift A to the 1st floor 4. Follow signs to Library. This route avoids all stairs."
  * Action Card inside bubble: "View Route on Map ->"
- Quick Suggestion Prompts:
  * "Where is the nearest accessible toilet?"
  * "How do I reach Block B without stairs?"
  * "Is the lift near the library working?"
- Bottom Input Bar with mic button, text field, and send arrow.

Screen 6: "📱 Mobile Welcome / Home Screen (390x844 mobile frame)"
- Top App Bar with hamburger menu, Brand mark "SmartAccess Campus", Profile avatar.
- Hero Banner with title "Navigate your campus. Your way.", subtitle "An inclusive campus navigation platform for everyone, everywhere."
- Search bar with facility search auto-complete.
- "Choose Accessibility Mode" 4-button quick bar.
- Quick navigation cards:
  * Explore Campus (View map, buildings & facilities)
  * Report an Issue (Help us keep the campus accessible)
  * Ask Campus AI (Get instant answers)
- Bottom Mascot illustration with slogan "Accessible Campus, Stronger Community".
- Bottom Navigation Bar (Home, Map, Route, Report, Profile).

ORGANIZATION RULES:
- Use Figma Auto-Layout on all containers (Shift+A).
- Wrap repeating items into Component Sets with Boolean properties for icons and badges.
- Assign all colors to Figma Local Variables.
- No detached styles or flattened bitmaps.`;

export const FIGMA_TOKENS_STUDIO_JSON = {
  $name: 'SmartAccess Campus Design Tokens',
  $version: '2.0.0',
  color: {
    brand: {
      primary: {
        50: { value: '#eff6ff', type: 'color' },
        100: { value: '#dbeafe', type: 'color' },
        500: { value: '#3b82f6', type: 'color' },
        600: { value: '#2563eb', type: 'color', description: 'Core Action & Wheelchair Mode' },
        700: { value: '#1d4ed8', type: 'color' },
      },
      secondary: {
        violet: { value: '#8b5cf6', type: 'color', description: 'No-Stairs Mode' },
        teal: { value: '#059669', type: 'color', description: 'Visual Assistance Mode' },
        amber: { value: '#f59e0b', type: 'color', description: 'Warning & In-Progress' },
        rose: { value: '#ef4444', type: 'color', description: 'Broken Facility / Hazard' },
      },
    },
    surface: {
      canvas: { value: '#f8fafc', type: 'color' },
      card: { value: '#ffffff', type: 'color' },
      sidebar: { value: '#0f172a', type: 'color' },
      border: { value: '#e2e8f0', type: 'color' },
    },
    text: {
      primary: { value: '#0f172a', type: 'color' },
      secondary: { value: '#64748b', type: 'color' },
      muted: { value: '#94a3b8', type: 'color' },
      inverted: { value: '#ffffff', type: 'color' },
    },
    mode: {
      wheelchair: { value: '{color.brand.primary.600}', type: 'color' },
      noStairs: { value: '{color.brand.secondary.violet}', type: 'color' },
      visualAssist: { value: '{color.brand.secondary.teal}', type: 'color' },
      normal: { value: '#475569', type: 'color' },
    },
  },
  borderRadius: {
    sm: { value: '6px', type: 'borderRadius' },
    md: { value: '10px', type: 'borderRadius' },
    lg: { value: '16px', type: 'borderRadius' },
    xl: { value: '24px', type: 'borderRadius' },
    full: { value: '9999px', type: 'borderRadius' },
  },
  spacing: {
    xs: { value: '4px', type: 'spacing' },
    sm: { value: '8px', type: 'spacing' },
    md: { value: '12px', type: 'spacing' },
    lg: { value: '16px', type: 'spacing' },
    xl: { value: '24px', type: 'spacing' },
    '2xl': { value: '32px', type: 'spacing' },
  },
  fontFamilies: {
    sans: { value: 'Plus Jakarta Sans', type: 'fontFamilies' },
    mono: { value: 'JetBrains Mono', type: 'fontFamilies' },
  },
  fontSizes: {
    xs: { value: '12px', type: 'fontSizes' },
    sm: { value: '14px', type: 'fontSizes' },
    base: { value: '16px', type: 'fontSizes' },
    lg: { value: '18px', type: 'fontSizes' },
    xl: { value: '20px', type: 'fontSizes' },
    '2xl': { value: '24px', type: 'fontSizes' },
    '3xl': { value: '32px', type: 'fontSizes' },
  },
  boxShadow: {
    card: {
      value: {
        x: '0px',
        y: '2px',
        blur: '8px',
        spread: '0px',
        color: 'rgba(15, 23, 42, 0.06)',
        type: 'dropShadow',
      },
      type: 'boxShadow',
    },
  },
};

export const COMPONENT_VARIANTS_SPEC = [
  {
    name: 'AccessibilityModeTab',
    description: '4-way toggle for user mobility preference',
    variants: [
      { property: 'Mode', values: ['Wheelchair', 'No-Stairs', 'Visual-Assist', 'Normal'] },
      { property: 'State', values: ['Default', 'Active', 'Hover', 'Focused'] },
      { property: 'Size', values: ['Small (Mobile)', 'Medium (Desktop)'] },
    ],
    tokensUsed: ['color.mode.*', 'borderRadius.lg', 'spacing.md'],
  },
  {
    name: 'MetricKpiCard',
    description: 'Dashboard KPI metric tile with icon, title, tabular count, and delta tag',
    variants: [
      { property: 'Variant', values: ['ReportedIssues', 'ActiveUsers', 'WorkingLifts', 'AccessibleRamps'] },
      { property: 'Severity', values: ['Normal', 'Warning', 'Critical'] },
    ],
    tokensUsed: ['surface.card', 'color.brand.*', 'fontSizes.3xl', 'boxShadow.card'],
  },
  {
    name: 'RouteTimelineStep',
    description: 'Vertical route step card with transit icon and accessibility metadata',
    variants: [
      { property: 'Type', values: ['Origin', 'Ramp', 'Building', 'Lift', 'Floor', 'Destination'] },
      { property: 'IsLast', values: ['True', 'False'] },
      { property: 'Accessible', values: ['True', 'False'] },
    ],
    tokensUsed: ['spacing.lg', 'color.brand.primary.600', 'borderRadius.md'],
  },
  {
    name: 'MapLocationPin',
    description: 'Interactive pin placed on campus blueprint',
    variants: [
      { property: 'Type', values: ['Building', 'Ramp', 'Lift', 'Toilet', 'Entrance', 'UserCurrent'] },
      { property: 'Selected', values: ['True', 'False'] },
    ],
    tokensUsed: ['color.mode.*', 'boxShadow.card'],
  },
];
